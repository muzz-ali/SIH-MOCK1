# System Architecture & Technical Specifications

## 1. High-Level Architecture Overview
The platform follows a clean, decoupled 4-tier architecture designed for high scalability, fault tolerance in rural environments, and seamless collaboration between team members.

```
+-------------------------------------------------------------------------+
|                          STUDENT CLIENT LAYER                           |
|       (React + TypeScript / Modern ES6 SPA + Tailwind CSS + Web Audio)   |
|   - Gamified Dashboard     - Quiz Screen w/ TTS     - Leaderboards      |
|   - Mitra AI Chat          - Progress & Badges      - Offline Cache     |
+-------------------------------------------------------------------------+
                                    │
                                    │ HTTPS / REST (JSON)
                                    ▼
+-------------------------------------------------------------------------+
|                         API GATEWAY & BACKEND                           |
|                           (Python + FastAPI)                            |
|   - /api/v1/auth & User Profiles      - /api/v1/quiz & Grading Engine   |
|   - /api/v1/daily-challenge           - /api/v1/leaderboard             |
|   - /api/v1/progress & Analytics      - /api/v1/ai/tutor                |
+-------------------------------------------------------------------------+
               │                                            │
               ▼                                            ▼
+-----------------------------+             +-----------------------------+
|      DATABASE LAYER         |             |       AI ENGINE LAYER       |
|       (PostgreSQL)          |             |  (Adaptive Learning Engine) |
| - 200+ Rural Question Bank  |             | - Knowledge State (BKT/IRT) |
| - Student XP & Level State  |             | - Misconception Analyzer    |
| - Daily Streak History      |             | - Personalized Recommendations |
+-----------------------------+             +-----------------------------+
```

## 2. Component Responsibilities

### Tier 1: Frontend Client (Farhan)
- **Role**: Responsive, tactile, low-bandwidth UI/UX.
- **Tech Stack**: HTML5, Vanilla/Modern JS/TS, Tailwind CSS, Lucide Icons, Web Speech API (TTS), Web Audio API (Synthesizer).
- **Core Principles**:
  - Authoritative data display only (Frontend never invents scores, XP formulas, or questions).
  - Dedicated API Service layer (`src/services/api.js`).
  - Seamless offline caching using browser `localStorage` when internet is disconnected.

### Tier 2: Backend REST Services (Rehan & Nabeel)
- **Role**: Business logic, authoritative scoring, question dispatch, user session management.
- **Tech Stack**: Python, FastAPI, Pydantic, SQLAlchemy, PostgreSQL.

### Tier 3: AI Intelligence Layer (Person 3)
- **Role**: Evaluates quiz performance, identifies conceptual misconceptions, generates tailored hints, and outputs personalized practice quests.

### Tier 4: Tech Lead & DevOps (Muzammil)
- **Role**: Contract enforcement (`docs/API.md`), automated testing, database migration, CI/CD pipeline, and final demonstration orchestration.
