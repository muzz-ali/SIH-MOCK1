# Authoritative REST API Specifications (v1.0)

> [!IMPORTANT]
> This document is the **Single Source of Truth** for all API communication.
> Frontend MUST NOT invent fields, rename endpoints, or alter payloads.
> Base URL: `http://localhost:8000/api/v1` (or configured via environment)

---

## 1. User & Profile Endpoints

### `GET /api/v1/user/profile`
Retrieve current authenticated student profile, XP, level, and streak status.

**Response `200 OK`**:
```json
{
  "id": "std_1024",
  "name": "Aarav Sharma",
  "avatar": "owl_scholar",
  "grade": 6,
  "school": "ZP High School, Satara",
  "district": "Satara",
  "state": "Maharashtra",
  "xp": 1420,
  "level": 4,
  "level_title": "Star Explorer",
  "xp_to_next_level": 580,
  "current_level_xp": 420,
  "total_level_xp_needed": 1000,
  "streak_days": 5,
  "streak_active_today": true,
  "badges": [
    {"id": "b1", "name": "Math Wizard", "icon": "calculator", "unlocked_at": "2026-08-10"},
    {"id": "b2", "name": "5-Day Streak", "icon": "flame", "unlocked_at": "2026-08-14"},
    {"id": "b3", "name": "Nature Explorer", "icon": "leaf", "unlocked_at": "2026-08-12"}
  ],
  "preferred_language": "hi"
}
```

---

## 2. Subjects & Categories

### `GET /api/v1/subjects`
Returns list of available learning domains.

**Response `200 OK`**:
```json
[
  {
    "id": "math",
    "name": "Mathematics",
    "name_hi": "गणित",
    "icon": "calculator",
    "color": "emerald",
    "completed_quests": 18,
    "total_quests": 25,
    "mastery_percentage": 72,
    "topics": ["Fractions", "Vedic Multiplication", "Shapes & Area", "Word Problems"]
  },
  {
    "id": "science",
    "name": "Science & Nature",
    "name_hi": "विज्ञान और प्रकृति",
    "icon": "flask-conical",
    "color": "sky",
    "completed_quests": 14,
    "total_quests": 20,
    "mastery_percentage": 68,
    "topics": ["Plant Life", "Water Cycle", "Solar System", "Soil & Agriculture"]
  },
  {
    "id": "english",
    "name": "English & Stories",
    "name_hi": "अंग्रेजी और कहानियाँ",
    "icon": "book-open",
    "color": "violet",
    "completed_quests": 10,
    "total_quests": 20,
    "mastery_percentage": 55,
    "topics": ["Vocabulary", "Grammar Fun", "Rhymes & Poems", "Story Comprehension"]
  },
  {
    "id": "gk",
    "name": "Village GK & India",
    "name_hi": "सामान्य ज्ञान और भारत",
    "icon": "landmark",
    "color": "amber",
    "completed_quests": 12,
    "total_quests": 15,
    "mastery_percentage": 80,
    "topics": ["Indian Heritage", "Panchayat & Community", "Rivers & Seasons", "Great Leaders"]
  },
  {
    "id": "logic",
    "name": "Brain Teasers & Logic",
    "name_hi": "तर्क और पहेलियाँ",
    "icon": "brain",
    "color": "rose",
    "completed_quests": 8,
    "total_quests": 15,
    "mastery_percentage": 60,
    "topics": ["Number Patterns", "Visual Puzzles", "Riddles", "Logical Deductions"]
  }
]
```

---

## 3. Quiz Generation & Submission

### `POST /api/v1/quiz/generate`
Generates a 5-question targeted or subject quiz.

**Request Body**:
```json
{
  "subject_id": "math",
  "difficulty": "medium",
  "mode": "practice"
}
```

**Response `200 OK`**:
```json
{
  "quiz_id": "qz_9921",
  "subject_id": "math",
  "subject_name": "Mathematics",
  "total_questions": 5,
  "time_limit_seconds": 300,
  "xp_reward": 100,
  "questions": [
    {
      "id": "q_101",
      "question": "What is 3/4 + 1/4 in simplified form?",
      "question_hi": "3/4 + 1/4 का सरलतम रूप क्या है?",
      "options": ["1/2", "1", "4/8", "2"],
      "options_hi": ["1/2", "1", "4/8", "2"],
      "topic": "Fractions",
      "hint": "When denominators are the same, just add the numerators (3 + 1)."
    }
  ]
}
```

### `POST /api/v1/quiz/submit`
Submits student answers for authoritative grading and AI analysis.

**Request Body**:
```json
{
  "quiz_id": "qz_9921",
  "answers": [
    {"question_id": "q_101", "selected_option_index": 1, "time_taken_seconds": 12}
  ]
}
```

**Response `200 OK`**:
```json
{
  "submission_id": "sub_4412",
  "score": 4,
  "total_questions": 5,
  "accuracy_percentage": 80,
  "xp_earned": 120,
  "bonus_xp": 20,
  "new_total_xp": 1540,
  "leveled_up": false,
  "new_level": 4,
  "streak_updated": true,
  "new_streak_days": 5,
  "ai_analysis": {
    "strong_topics": ["Fractions", "Multiplication"],
    "weak_topics": ["Word Problems"],
    "feedback_text": "Shabash Aarav! You showed fantastic speed on fraction additions. Let's practice 2 more word problems to master this topic completely!",
    "recommended_quiz": {
      "subject_id": "math",
      "topic": "Word Problems",
      "title": "Fractions in Farm Life"
    }
  },
  "question_breakdown": [
    {
      "question_id": "q_101",
      "is_correct": true,
      "correct_option_index": 1,
      "user_option_index": 1,
      "explanation": "3/4 + 1/4 = (3+1)/4 = 4/4 = 1. Excellent!"
    }
  ]
}
```

---

## 4. Daily Challenge

### `GET /api/v1/daily-challenge`
Retrieve today's special quest with time multiplier.

**Response `200 OK`**:
```json
{
  "challenge_id": "dc_2026_08_15",
  "title": "Independence Day Math & Science Special",
  "title_hi": "स्वतंत्रता दिवस गणित एवं विज्ञान विशेष",
  "description": "Solve 5 quick questions on Indian inventions & speed math!",
  "xp_reward": 150,
  "streak_boost": 1,
  "is_completed": false,
  "expires_in_seconds": 33120,
  "total_questions": 5
}
```

---

## 5. Leaderboard

### `GET /api/v1/leaderboard?scope=village`
Scopes: `village`, `district`, `all_india`.

**Response `200 OK`**:
```json
{
  "scope": "village",
  "scope_name": "ZP High School, Satara",
  "my_rank": {
    "rank": 4,
    "student_name": "Aarav Sharma",
    "xp": 1420,
    "level": 4,
    "streak": 5,
    "avatar": "owl_scholar"
  },
  "top_students": [
    {
      "rank": 1,
      "student_name": "Pooja Patil",
      "school": "ZP High School",
      "xp": 2890,
      "level": 7,
      "streak": 14,
      "avatar": "peacock_hero"
    },
    {
      "rank": 2,
      "student_name": "Rohan Deshmukh",
      "school": "ZP High School",
      "xp": 2410,
      "level": 6,
      "streak": 9,
      "avatar": "tiger_champion"
    },
    {
      "rank": 3,
      "student_name": "Kavita Shinde",
      "school": "ZP High School",
      "xp": 1980,
      "level": 5,
      "streak": 7,
      "avatar": "elephant_sage"
    }
  ]
}
```

---

## 6. AI Tutor ("Mitra AI")

### `POST /api/v1/ai/tutor`
Interactive doubt solving with rural pedagogical analogies.

**Request Body**:
```json
{
  "student_query": "Why do plants need sunlight?",
  "language": "hi",
  "grade": 6
}
```

**Response `200 OK`**:
```json
{
  "reply_text": "जैसे हमारी रसोई में खाना बनाने के लिए आग या गैस चाहिए, वैसे ही पौधे की पत्तियाँ (रसोई) सूर्य के प्रकाश (धूप) से खाना बनाती हैं! इस जादुई क्रिया को प्रकाश-संश्लेषण (Photosynthesis) कहते हैं।",
  "reply_text_en": "Just like we need fire/stove in our kitchen to cook food, leaves of plants use sunlight as energy to cook food! This magical process is called Photosynthesis.",
  "suggested_followups": [
    "पौधे पानी कहाँ से लेते हैं?",
    "रात में पौधे क्या करते हैं?"
  ]
}
```
