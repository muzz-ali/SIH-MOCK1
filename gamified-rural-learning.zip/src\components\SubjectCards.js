/**
 * Subject Cards Grid Component for Questify (3 Core Subjects: Math, Science, General Knowledge)
 */

export function renderSubjectCards(state) {
  const { subjects, currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  const iconsMap = {
    math: '🔢',
    science: '🌱',
    gk: '🌾'
  };

  return `
    <div class="mb-10">
      
      <!-- Section Header -->
      <div class="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-2xl">📚</span>
            <h2 class="text-2xl sm:text-3xl font-game font-bold text-slate-900 dark:text-white">
              ${isHi ? 'सीखने के मुख्य विषय' : 'Subject Quests'}
            </h2>
          </div>
          <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">
            ${isHi ? 'गणित, विज्ञान और सामान्य ज्ञान में अपनी महारत बढ़ाएं' : 'Master your core fundamentals in Mathematics, Science & General Knowledge'}
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span>🎯</span>
          <span>${isHi ? 'कक्षा 6वीं पाठ्यक्रम' : 'Class 6 Curriculum'}</span>
        </div>
      </div>

      <!-- 3-Column Subject Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        ${subjects.map(sub => {
          const icon = iconsMap[sub.id] || '📖';
          const name = isHi ? (sub.name_hi || sub.name) : sub.name;
          
          return `
            <div class="card-rural p-6 flex flex-col justify-between hover:shadow-lg transition-all border-slate-200 dark:border-slate-800 border-b-4 hover:border-slate-300 dark:hover:border-slate-700 relative group overflow-hidden bg-white dark:bg-slate-800">
              
              <!-- Subtle Background Glow -->
              <div class="absolute -right-8 -top-8 w-24 h-24 rounded-full bg-slate-100 dark:bg-slate-700/50 group-hover:scale-150 transition-transform -z-0"></div>

              <div class="relative z-10">
                <!-- Top Badge & Icon -->
                <div class="flex items-center justify-between mb-4">
                  <div class="w-14 h-14 rounded-2xl ${sub.bgLight} ${sub.borderLight} border-2 flex items-center justify-center text-3xl shadow-sm group-hover:scale-110 transition-transform">
                    ${icon}
                  </div>
                  <span class="px-2.5 py-1 rounded-full text-xs font-game font-bold ${sub.bgLight} ${sub.textDark} border ${sub.borderLight}">
                    ${sub.badge}
                  </span>
                </div>

                <!-- Subject Title -->
                <h3 class="font-game text-xl font-bold text-slate-800 dark:text-slate-100 mb-1 group-hover:text-emerald-500 transition-colors">
                  ${name}
                </h3>
                
                <!-- Topic Chips -->
                <div class="flex flex-wrap gap-1.5 my-3">
                  ${sub.topics.slice(0, 3).map(topic => `
                    <span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[11px] font-medium">
                      ${topic}
                    </span>
                  `).join('')}
                </div>

                <!-- Mastery Progress Bar -->
                <div class="space-y-1.5 my-4">
                  <div class="flex justify-between text-xs font-bold">
                    <span class="text-slate-500 dark:text-slate-400">${isHi ? 'महारत (Mastery)' : 'Mastery'}</span>
                    <span class="${sub.textDark}">${sub.mastery_percentage}%</span>
                  </div>
                  <div class="w-full h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5 border border-slate-200 dark:border-slate-600">
                    <div class="h-full rounded-full transition-all duration-500" style="width: ${sub.mastery_percentage}%; background-color: ${sub.accentColor}"></div>
                  </div>
                  <div class="flex justify-between text-[11px] text-slate-400 font-medium">
                    <span>${sub.completed_quests}/${sub.total_quests} ${isHi ? 'क्वेस्ट पूरे' : 'Quests Done'}</span>
                    <span>⭐⭐⭐</span>
                  </div>
                </div>
              </div>

              <!-- Start Button -->
              <div class="relative z-10 pt-2">
                <button class="btn-3d btn-3d-primary w-full py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 shadow-md btn-start-subject-quiz" data-subject-id="${sub.id}">
                  <span>▶️</span>
                  <span>${isHi ? 'अभ्यास शुरू करें (+100 XP)' : 'Start Practice (+100 XP)'}</span>
                </button>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}
