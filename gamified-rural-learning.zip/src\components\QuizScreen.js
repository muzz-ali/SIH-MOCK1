/**
 * Interactive Quiz Arena Component for Questify
 * Features tactile 3D options, audio TTS narration, lifelines & dark mode support
 */

export function renderQuizScreen(state) {
  const { currentQuiz, currentQuestionIndex, userAnswers, currentLanguage, quizLifelines, isDailyChallenge } = state;
  const isHi = currentLanguage === 'hi';

  if (!currentQuiz || !currentQuiz.questions || !currentQuiz.questions.length) {
    return `
      <div class="card-rural p-12 text-center max-w-lg mx-auto my-12 bg-white dark:bg-slate-800">
        <span class="text-5xl animate-bounce">⏳</span>
        <h3 class="font-game text-2xl font-bold text-slate-800 dark:text-white mt-4">Loading Quiz...</h3>
        <p class="text-sm text-slate-500 dark:text-slate-400 mt-2">Connecting to question bank...</p>
      </div>
    `;
  }

  const total = currentQuiz.total_questions;
  const currentQ = currentQuiz.questions[currentQuestionIndex];
  const currentAnswer = userAnswers.find(a => a.question_id === currentQ.id);
  const selectedIndex = currentAnswer ? currentAnswer.selected_option_index : null;

  const currentLifeline = quizLifelines[currentQ.id] || { fiftyFiftyUsed: false, hintUsed: false, hiddenOptions: [] };

  const questionText = isHi ? (currentQ.question_hi || currentQ.question) : currentQ.question;
  const optionsList = isHi ? (currentQ.options_hi || currentQ.options) : currentQ.options;

  const optionLetters = ['A', 'B', 'C', 'D'];
  const progressPercent = Math.round(((currentQuestionIndex + 1) / total) * 100);

  return `
    <div class="max-w-4xl mx-auto py-4 px-2 sm:px-4">
      
      <!-- Top Quiz Status Bar -->
      <div class="card-rural p-4 sm:p-5 mb-6 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
        
        <div class="flex items-center justify-between gap-4 flex-wrap mb-4">
          
          <!-- Subject & Mode Tag -->
          <div class="flex items-center gap-2">
            <button id="btn-quiz-exit" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-rose-50 dark:hover:bg-rose-950 hover:text-rose-600 text-slate-600 dark:text-slate-200 border border-slate-200 dark:border-slate-600 text-xs font-bold transition-all" title="Exit Quiz">
              ✖ ${isHi ? 'बाहर निकलें' : 'Exit'}
            </button>
            <span class="px-3 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-game font-bold">
              ${isDailyChallenge ? '⚡ ' + (isHi ? 'दैनिक चुनौती' : 'Daily Quest') : '📚 ' + (isHi ? (currentQuiz.subject_name_hi || currentQuiz.subject_name) : currentQuiz.subject_name)}
            </span>
            <span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[11px] font-semibold">
              ${currentQ.topic || 'Core'}
            </span>
          </div>

          <!-- Lifelines Toolbar -->
          <div class="flex items-center gap-2">
            <!-- 50:50 Lifeline -->
            <button id="btn-lifeline-fifty" class="btn-3d ${currentLifeline.fiftyFiftyUsed ? 'opacity-40 cursor-not-allowed bg-slate-200 dark:bg-slate-700 text-slate-400 border-slate-300' : 'btn-3d-white text-indigo-600 dark:text-indigo-400'} px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5" ${currentLifeline.fiftyFiftyUsed ? 'disabled' : ''} title="Eliminate 2 wrong answers">
              <span>✂️</span>
              <span>50:50</span>
            </button>

            <!-- Hint Lifeline -->
            <button id="btn-lifeline-hint" class="btn-3d ${currentLifeline.hintUsed ? 'opacity-40 cursor-not-allowed bg-slate-200 dark:bg-slate-700 text-slate-400 border-slate-300' : 'btn-3d-amber'} px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5" ${currentLifeline.hintUsed ? 'disabled' : ''} title="Get a hint from Quest AI">
              <span>💡</span>
              <span>${isHi ? 'संकेत (Hint)' : 'AI Hint'}</span>
            </button>

            <!-- Question Number Indicator -->
            <div class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold font-game border border-slate-200 dark:border-slate-600">
              ${currentQuestionIndex + 1} / ${total}
            </div>
          </div>

        </div>

        <!-- Animated Progress Bar -->
        <div class="relative pt-6 pb-2">
          <!-- Runner Icon traveling along the track -->
          <div class="absolute -top-1 transition-all duration-500 transform -translate-x-1/2 flex flex-col items-center" style="left: ${progressPercent}%;">
            <span class="text-xl animate-mascot">✨</span>
          </div>
          
          <div class="w-full h-3.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5 border border-slate-200 dark:border-slate-600">
            <div class="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full transition-all duration-500" style="width: ${progressPercent}%;"></div>
          </div>

          <!-- Step Dots -->
          <div class="flex justify-between mt-1 px-1 text-[11px] text-slate-400 dark:text-slate-500 font-bold">
            ${currentQuiz.questions.map((_, i) => `
              <span class="${i <= currentQuestionIndex ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-300 dark:text-slate-600'}">
                ${i + 1}
              </span>
            `).join('')}
          </div>
        </div>

      </div>

      <!-- Main Question Card -->
      <div class="card-rural p-6 sm:p-8 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 border-b-4 mb-6 shadow-md">
        
        <!-- Question Header & Audio Speak Button -->
        <div class="flex items-start justify-between gap-4 mb-6">
          <div class="space-y-1">
            <span class="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
              <span>🎯</span> ${isHi ? `प्रश्न ${currentQuestionIndex + 1}` : `Question ${currentQuestionIndex + 1}`}
            </span>
            <h2 class="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white font-game leading-relaxed">
              ${questionText}
            </h2>
          </div>

          <!-- Audio Read Aloud Button -->
          <button id="btn-speak-question" class="btn-3d btn-3d-white p-3 rounded-2xl text-emerald-600 dark:text-emerald-400 shrink-0 shadow-sm hover:scale-105 transition-all" title="Listen to Question">
            <span class="text-xl">🔊</span>
          </button>
        </div>

        <!-- Optional AI Hint Callout -->
        ${currentLifeline.hintUsed ? `
          <div class="mb-6 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-200 dark:border-amber-800 flex items-start gap-3 shadow-inner">
            <span class="text-2xl">💡</span>
            <div>
              <p class="text-xs font-bold text-amber-900 dark:text-amber-300 uppercase">${isHi ? 'क्वेस्ट AI का संकेत' : 'Quest AI Clue'}</p>
              <p class="text-sm text-amber-800 dark:text-amber-200 font-medium mt-0.5">${currentQ.hint || 'Read the question carefully.'}</p>
            </div>
          </div>
        ` : ''}

        <!-- Interactive 3D Options Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
          ${optionsList.map((opt, idx) => {
            const isHiddenBy5050 = currentLifeline.hiddenOptions.includes(idx);
            const isSelected = selectedIndex === idx;

            if (isHiddenBy5050) {
              return `
                <div class="quiz-option p-4 sm:p-5 opacity-20 cursor-not-allowed bg-slate-100 dark:bg-slate-800 border-dashed border-slate-300 dark:border-slate-700 flex items-center gap-3">
                  <span class="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-400 flex items-center justify-center font-game font-bold text-sm">
                    ${optionLetters[idx]}
                  </span>
                  <span class="text-slate-400 font-medium text-sm line-through">---</span>
                </div>
              `;
            }

            return `
              <div class="quiz-option p-4 sm:p-5 flex items-center gap-3.5 select-none ${isSelected ? 'selected' : ''}" data-option-index="${idx}">
                <div class="w-9 h-9 shrink-0 rounded-xl ${isSelected ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600'} flex items-center justify-center font-game font-bold text-base transition-all">
                  ${optionLetters[idx]}
                </div>
                <span class="text-slate-800 dark:text-slate-200 font-semibold text-sm sm:text-base leading-snug">
                  ${opt}
                </span>
              </div>
            `;
          }).join('')}
        </div>

      </div>

      <!-- Navigation & Submit Bar -->
      <div class="flex items-center justify-between gap-4">
        
        <button id="btn-quiz-prev" class="btn-3d btn-3d-white px-5 py-3 rounded-2xl text-sm font-bold flex items-center gap-2 ${currentQuestionIndex === 0 ? 'opacity-40 cursor-not-allowed' : ''}" ${currentQuestionIndex === 0 ? 'disabled' : ''}>
          <span>⬅️</span>
          <span>${isHi ? 'पिछला प्रश्न' : 'Previous'}</span>
        </button>

        <!-- Question Dots / Jump Drawer -->
        <div class="hidden sm:flex items-center gap-1.5">
          ${currentQuiz.questions.map((q, idx) => {
            const ans = userAnswers.find(a => a.question_id === q.id);
            const isCurr = idx === currentQuestionIndex;
            return `
              <button class="w-8 h-8 rounded-xl font-game font-bold text-xs flex items-center justify-center transition-all ${isCurr ? 'bg-indigo-600 text-white shadow-md scale-110' : (ans ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700')} btn-quiz-jump" data-target-index="${idx}">
                ${idx + 1}
              </button>
            `;
          }).join('')}
        </div>

        ${currentQuestionIndex === total - 1 ? `
          <button id="btn-quiz-submit" class="btn-3d btn-3d-primary px-7 py-3 rounded-2xl text-base font-bold flex items-center gap-2 shadow-lg pulse-active">
            <span>🏁</span>
            <span>${isHi ? 'क्विज समाप्त करें' : 'Finish & Submit'}</span>
          </button>
        ` : `
          <button id="btn-quiz-next" class="btn-3d btn-3d-primary px-6 py-3 rounded-2xl text-sm font-bold flex items-center gap-2 shadow-md">
            <span>${isHi ? 'अगला प्रश्न' : 'Next'}</span>
            <span>➡️</span>
          </button>
        `}

      </div>

    </div>
  `;
}
