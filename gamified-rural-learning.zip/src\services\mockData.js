/**
 * Mock Data Store strictly matching docs/API.md structures for Questify
 * Features 3 core subjects: Mathematics, Science, General Knowledge
 */

export const mockUserProfile = {
  id: "std_1024",
  name: "Aarav Sharma",
  avatar: "peacock_hero",
  grade: 6,
  school: "ZP High School, Satara",
  district: "Satara",
  state: "Maharashtra",
  xp: 1420,
  level: 4,
  level_title: "Star Explorer",
  xp_to_next_level: 580,
  current_level_xp: 420,
  total_level_xp_needed: 1000,
  streak_days: 5,
  streak_active_today: true,
  badges: [
    { id: "b1", name: "Math Wizard", name_hi: "गणित का जादूगर", icon: "calculator", color: "emerald", unlocked_at: "2026-08-10" },
    { id: "b2", name: "5-Day Streak", name_hi: "5 दिन की लपट", icon: "flame", color: "amber", unlocked_at: "2026-08-14" },
    { id: "b3", name: "Science Explorer", name_hi: "विज्ञान खोजी", icon: "flask-conical", color: "sky", unlocked_at: "2026-08-12" },
    { id: "b4", name: "Speed Master", name_hi: "तेज दिमाग", icon: "zap", color: "yellow", unlocked_at: "2026-08-08" },
    { id: "b5", name: "GK Champion", name_hi: "सामान्य ज्ञान सितारा", icon: "landmark", color: "amber", unlocked_at: "2026-08-05" }
  ],
  preferred_language: "en"
};

export const mockSubjects = [
  {
    id: "math",
    name: "Mathematics",
    name_hi: "गणित",
    icon: "calculator",
    badge: "Core Quest",
    color: "emerald",
    bgLight: "bg-emerald-50 dark:bg-emerald-950/40",
    borderLight: "border-emerald-200 dark:border-emerald-800",
    textDark: "text-emerald-700 dark:text-emerald-400",
    accentColor: "#10b981",
    completed_quests: 18,
    total_quests: 25,
    mastery_percentage: 72,
    topics: ["Fractions", "Multiplication", "Shapes & Area", "Word Problems"]
  },
  {
    id: "science",
    name: "Science",
    name_hi: "विज्ञान",
    icon: "flask-conical",
    badge: "Discovery",
    color: "sky",
    bgLight: "bg-sky-50 dark:bg-sky-950/40",
    borderLight: "border-sky-200 dark:border-sky-800",
    textDark: "text-sky-700 dark:text-sky-400",
    accentColor: "#0ea5e9",
    completed_quests: 14,
    total_quests: 20,
    mastery_percentage: 68,
    topics: ["Plant Life", "Water Cycle", "Solar System", "Soil & Agriculture"]
  },
  {
    id: "gk",
    name: "General Knowledge",
    name_hi: "सामान्य ज्ञान",
    icon: "landmark",
    badge: "World & India",
    color: "amber",
    bgLight: "bg-amber-50 dark:bg-amber-950/40",
    borderLight: "border-amber-200 dark:border-amber-800",
    textDark: "text-amber-700 dark:text-amber-400",
    accentColor: "#f59e0b",
    completed_quests: 12,
    total_quests: 15,
    mastery_percentage: 80,
    topics: ["Indian Heritage", "Civics & Governance", "Rivers & Seasons", "Great Leaders"]
  }
];

export const mockDailyChallenge = {
  challenge_id: "dc_2026_08_15",
  title: "Daily Sprint Challenge",
  title_hi: "दैनिक तीव्र चुनौती",
  description: "Answer 5 quick questions across Math, Science & General Knowledge to earn +150 bonus XP!",
  description_hi: "+150 बोनस XP जीतने के लिए गणित, विज्ञान और सामान्य ज्ञान पर 5 त्वरित प्रश्नों के उत्तर दें!",
  xp_reward: 150,
  streak_boost: 1,
  is_completed: false,
  expires_in_seconds: 28400,
  total_questions: 5,
  subject_id: "gk"
};

export const mockQuestionBank = {
  math: [
    {
      id: "q_m1",
      question: "What is 3/4 + 1/4 in simplified form?",
      question_hi: "3/4 + 1/4 का सरलतम रूप क्या है?",
      options: ["1/2", "1", "4/8", "2"],
      options_hi: ["1/2", "1", "4/8", "2"],
      correct_index: 1,
      topic: "Fractions",
      hint: "When denominators are the same, just add the numerators: 3 + 1 = 4. What is 4/4?",
      explanation: "3/4 + 1/4 = (3+1)/4 = 4/4 = 1. Excellent job!"
    },
    {
      id: "q_m2",
      question: "A farmer has 7 baskets of mangoes. Each basket has 12 mangoes. How many mangoes are there in total?",
      question_hi: "एक किसान के पास आम की 7 टोकरियाँ हैं। प्रत्येक टोकरी में 12 आम हैं। कुल कितने आम हैं?",
      options: ["72", "84", "96", "82"],
      options_hi: ["72", "84", "96", "82"],
      correct_index: 1,
      topic: "Word Problems",
      hint: "Multiply the number of baskets (7) by mangoes in each (12). 7 × 10 = 70, 7 × 2 = 14.",
      explanation: "7 × 12 = 84 mangoes in total. You solved it using simple Vedic breakdown!"
    },
    {
      id: "q_m3",
      question: "What is the perimeter of a square farmland whose one side is 15 meters?",
      question_hi: "एक वर्गाकार खेत का परिमाप क्या होगा जिसकी एक भुजा 15 मीटर है?",
      options: ["30 meters", "60 meters", "225 sq meters", "45 meters"],
      options_hi: ["30 मीटर", "60 मीटर", "225 वर्ग मीटर", "45 मीटर"],
      correct_index: 1,
      topic: "Shapes & Area",
      hint: "A square has 4 equal sides. Perimeter = 4 × side length.",
      explanation: "Perimeter of square = 4 × 15m = 60 meters. Great spatial understanding!"
    },
    {
      id: "q_m4",
      question: "Using quick multiplication: What is 25 × 25?",
      question_hi: "तेज गुणा: 25 × 25 क्या होगा?",
      options: ["525", "625", "650", "575"],
      options_hi: ["525", "625", "650", "575"],
      correct_index: 1,
      topic: "Multiplication",
      hint: "For numbers ending in 5: Multiply 2 by (2+1)=3 to get 6, and append 25. Result = 625!",
      explanation: "25 × 25 = 625. Vedic trick: (2 × 3) & 25 = 625."
    },
    {
      id: "q_m5",
      question: "If Mohan buys 3 pens for ₹15, what will be the cost of 7 such pens?",
      question_hi: "यदि मोहन ₹15 में 3 पेन खरीदता है, तो ऐसे 7 पेनों का मूल्य क्या होगा?",
      options: ["₹30", "₹35", "₹42", "₹25"],
      options_hi: ["₹30", "₹35", "₹42", "₹25"],
      correct_index: 1,
      topic: "Word Problems",
      hint: "First find cost of 1 pen: ₹15 ÷ 3 = ₹5. Then multiply by 7.",
      explanation: "1 pen = ₹5. Cost of 7 pens = 7 × ₹5 = ₹35."
    }
  ],
  science: [
    {
      id: "q_s1",
      question: "Which part of a plant acts like its 'food factory' using sunlight?",
      question_hi: "सूर्य के प्रकाश का उपयोग करके पौधे का कौन सा भाग 'रसोई' या भोजन बनाने का काम करता है?",
      options: ["Roots", "Leaves", "Stem", "Flowers"],
      options_hi: ["जड़ें (Roots)", "पत्तियाँ (Leaves)", "तना (Stem)", "फूल (Flowers)"],
      correct_index: 1,
      topic: "Plant Life",
      hint: "Green leaves have chlorophyll that captures sunlight for photosynthesis.",
      explanation: "Leaves produce food through Photosynthesis with the help of Chlorophyll, Sunlight, and Carbon Dioxide."
    },
    {
      id: "q_s2",
      question: "What is the process called when water turns into water vapor due to sun heat?",
      question_hi: "सूर्य की गर्मी से जल के वाष्प में बदलने की प्रक्रिया को क्या कहते हैं?",
      options: ["Condensation", "Evaporation", "Precipitation", "Freezing"],
      options_hi: ["संघनन (Condensation)", "वाष्पीकरण (Evaporation)", "वर्षा (Precipitation)", "जमना (Freezing)"],
      correct_index: 1,
      topic: "Water Cycle",
      hint: "Think about what happens to wet clothes drying in the sun.",
      explanation: "Evaporation occurs when liquid water heats up and turns into water vapor, rising into the sky to form clouds."
    },
    {
      id: "q_s3",
      question: "Which friendly creature is known as the 'Farmer’s Best Friend' because it aerates the soil?",
      question_hi: "किस जीव को मिट्टी को उपजाऊ बनाने के कारण 'किसान का सच्चा मित्र' कहा जाता है?",
      options: ["Honeybee", "Earthworm", "Grasshopper", "Sparrow"],
      options_hi: ["मधुमक्खी", "केंचुआ (Earthworm)", "टिड्डा", "गौरैया"],
      correct_index: 1,
      topic: "Soil & Agriculture",
      hint: "It burrows underground, making channels that let air and water reach plant roots.",
      explanation: "Earthworms decompose organic matter into vermicompost and loosen the soil, helping crops grow strong."
    },
    {
      id: "q_s4",
      question: "Which planet in our solar system is famously known as the 'Red Planet'?",
      question_hi: "हमारे सौरमंडल का कौन सा ग्रह 'लाल ग्रह' (Red Planet) के नाम से जाना जाता है?",
      options: ["Venus", "Mars", "Jupiter", "Mercury"],
      options_hi: ["शुक्र (Venus)", "मंगल (Mars)", "बृहस्पति (Jupiter)", "बुध (Mercury)"],
      correct_index: 1,
      topic: "Solar System",
      hint: "India launched the famous Mangalyaan mission to explore this planet!",
      explanation: "Mars appears red due to the large amount of iron oxide (rust) on its surface."
    },
    {
      id: "q_s5",
      question: "Which gas do trees take in during the day to produce clean Oxygen for us to breathe?",
      question_hi: "पेड़ हमें ताजी ऑक्सीजन देने के लिए दिन में कौन सी गैस अवशोषित करते हैं?",
      options: ["Nitrogen", "Carbon Dioxide", "Hydrogen", "Helium"],
      options_hi: ["नाइट्रोजन", "कार्बन डाइऑक्साइड (CO2)", "हाइड्रोजन", "हीलियम"],
      correct_index: 1,
      topic: "Plant Life",
      hint: "It's the gas exhaled by humans and animals.",
      explanation: "Trees absorb Carbon Dioxide during photosynthesis and release Oxygen, keeping our air fresh and pure."
    }
  ],
  gk: [
    {
      id: "q_g1",
      question: "Who is celebrated as the 'Father of the Nation' in India?",
      question_hi: "भारत में 'राष्ट्रपिता' के रूप में किसे याद किया जाता है?",
      options: ["Subhash Chandra Bose", "Mahatma Gandhi", "Bhagat Singh", "Sardar Patel"],
      options_hi: ["सुभाष चंद्र बोस", "महात्मा गांधी", "भगत सिंह", "सरदार पटेल"],
      correct_index: 1,
      topic: "Great Leaders",
      hint: "He led India to freedom through Ahimsa (Non-violence) and Truth.",
      explanation: "Mahatma Gandhi is revered as the Father of the Nation (Bapu) for leading the freedom movement."
    },
    {
      id: "q_g2",
      question: "What is the elected local council that governs and develops our villages called?",
      question_hi: "गाँवों के विकास और प्रशासन का संचालन करने वाली चुनी हुई परिषद को क्या कहते हैं?",
      options: ["Municipal Board", "Gram Panchayat", "District Court", "Vidhan Sabha"],
      options_hi: ["नगर पालिका", "ग्राम पंचायत (Gram Panchayat)", "जिला अदालत", "विधान सभा"],
      correct_index: 1,
      topic: "Civics & Governance",
      hint: "The head of this local body is called the Sarpanch or Gram Pradhan.",
      explanation: "The Gram Panchayat is the foundational local self-government institution in Indian villages."
    },
    {
      id: "q_g3",
      question: "What is the National Bird of India, known for its majestic rain dance?",
      question_hi: "भारत का राष्ट्रीय पक्षी कौन सा है, जो बारिश में अपने सुंदर नृत्य के लिए प्रसिद्ध है?",
      options: ["Eagle", "Indian Peacock", "Parrot", "Kingfisher"],
      options_hi: ["चील (Eagle)", "भारतीय मोर (Peacock)", "तोता (Parrot)", "नीलकंठ (Kingfisher)"],
      correct_index: 1,
      topic: "Indian Heritage",
      hint: "It has iridescent blue-green plumage and displays a fan of eye-spotted feathers.",
      explanation: "The Indian Peacock (Pavo cristatus) is India's National Bird, representing grace and vibrant beauty."
    },
    {
      id: "q_g4",
      question: "Which is the longest river flowing entirely within India, considered sacred by millions?",
      question_hi: "भारत की सबसे लंबी और प्रमुख नदी कौन सी है?",
      options: ["Yamuna", "Ganga", "Godavari", "Narmada"],
      options_hi: ["यमुना", "गंगा (Ganga)", "गोदावरी", "नर्मदा"],
      correct_index: 1,
      topic: "Rivers & Seasons",
      hint: "It originates from the Gangotri glacier in the Himalayas.",
      explanation: "River Ganga stretches over 2,525 km, irrigating fertile plains across North India."
    },
    {
      id: "q_g5",
      question: "What is the festival of harvest celebrated with joy in Southern India called?",
      question_hi: "दक्षिण भारत में फसल कटाई के उपलक्ष्य में मनाया जाने वाला प्रमुख त्योहार कौन सा है?",
      options: ["Baisakhi", "Pongal", "Onam", "Bihu"],
      options_hi: ["बैसाखी", "पोंगल (Pongal)", "ओणम", "बिहू"],
      correct_index: 1,
      topic: "Indian Heritage",
      hint: "A sweet dish with jaggery and rice is prepared in earthen pots.",
      explanation: "Pongal is the grand 4-day harvest festival celebrating Sun, Nature, and Cattle."
    }
  ]
};

export const mockLeaderboard = {
  village: {
    scope: "village",
    scope_name: "ZP High School, Satara",
    my_rank: {
      rank: 4,
      student_name: "Aarav Sharma (You)",
      school: "ZP High School",
      xp: 1420,
      level: 4,
      streak: 5,
      avatar: "peacock_hero"
    },
    top_students: [
      { rank: 1, student_name: "Pooja Patil", school: "ZP High School", xp: 2890, level: 7, streak: 14, avatar: "peacock_hero", badge: "Champ" },
      { rank: 2, student_name: "Rohan Deshmukh", school: "ZP High School", xp: 2410, level: 6, streak: 9, avatar: "tiger_champion", badge: "Math Star" },
      { rank: 3, student_name: "Kavita Shinde", school: "ZP High School", xp: 1980, level: 5, streak: 7, avatar: "elephant_sage", badge: "Science Pro" },
      { rank: 4, student_name: "Aarav Sharma (You)", school: "ZP High School", xp: 1420, level: 4, streak: 5, avatar: "peacock_hero", badge: "Explorer" },
      { rank: 5, student_name: "Siddharth More", school: "ZP High School", xp: 1310, level: 4, streak: 4, avatar: "squirrel_speed", badge: "Streak Rider" },
      { rank: 6, student_name: "Ananya Jadhav", school: "ZP High School", xp: 1190, level: 3, streak: 6, avatar: "peacock_hero", badge: "GK Star" }
    ]
  },
  district: {
    scope: "district",
    scope_name: "Satara District",
    my_rank: {
      rank: 24,
      student_name: "Aarav Sharma (You)",
      school: "ZP High School, Satara",
      xp: 1420,
      level: 4,
      streak: 5,
      avatar: "peacock_hero"
    },
    top_students: [
      { rank: 1, student_name: "Vikram Gaikwad", school: "Koregaon Model School", xp: 4200, level: 10, streak: 28, avatar: "tiger_champion", badge: "District Legend" },
      { rank: 2, student_name: "Sneha Pawar", school: "Karad Public Vidyalaya", xp: 3850, level: 9, streak: 21, avatar: "peacock_hero", badge: "District Topper" },
      { rank: 3, student_name: "Pooja Patil", school: "ZP High School, Satara", xp: 2890, level: 7, streak: 14, avatar: "peacock_hero", badge: "School Champ" }
    ]
  },
  all_india: {
    scope: "all_india",
    scope_name: "All India Quest Champions",
    my_rank: {
      rank: 184,
      student_name: "Aarav Sharma (You)",
      school: "ZP High School, Maharashtra",
      xp: 1420,
      level: 4,
      streak: 5,
      avatar: "peacock_hero"
    },
    top_students: [
      { rank: 1, student_name: "Aditya Kumar", school: "Govt School, Nalanda (Bihar)", xp: 9540, level: 18, streak: 60, avatar: "tiger_champion", badge: "National Prodigy" },
      { rank: 2, student_name: "Meera Reddy", school: "ZP High School, Warangal (Telangana)", xp: 8900, level: 17, streak: 54, avatar: "peacock_hero", badge: "Grand Scholar" },
      { rank: 3, student_name: "Devendra Verma", school: "Model School, Jaipur (Rajasthan)", xp: 8210, level: 16, streak: 45, avatar: "elephant_sage", badge: "Quest Titan" }
    ]
  }
};

export const mockAITutorResponses = [
  {
    keywords: ["photosynthesis", "sunlight", "plants", "food", "धूप", "पौधे", "प्रकाश"],
    reply_en: "Think of a green leaf like a mini kitchen! Sunlight is the energy, water from roots is the liquid, and air gives carbon dioxide. Leaves combine them to cook sweet glucose and release fresh Oxygen for us to breathe! This process is called Photosynthesis 🌱✨",
    reply_hi: "पत्ती को एक छोटी रसोई समझो! सूर्य के प्रकाश और मटके के पानी से पत्तियाँ अपना भोजन बनाती हैं और हमें ताजी ऑक्सीजन देती हैं! इसे प्रकाश-संश्लेषण कहते हैं 🌱✨",
    followups: ["Why are leaves green?", "How do roots drink water?", "Do plants sleep at night?"]
  },
  {
    keywords: ["fraction", "add", "math", "भिन्न", "जोड़", "गणित"],
    reply_en: "Imagine a big pizza or round roti! 🫓 If you cut it into 4 equal slices, each slice is 1/4. If your friend takes 1 slice and you take 2 slices, together you have 1 + 2 = 3 slices out of 4 (3/4). When the bottom denominators match, simply add the numerators on top!",
    reply_hi: "कल्पना करो एक गोल रोटी की! 🫓 यदि इसके 4 बराबर टुकड़े करें, तो हर टुकड़ा 1/4 है। 1 टुकड़ा और 2 टुकड़े मिलकर 3/4 होते हैं। जब नीचे की संख्या समान हो, तो केवल ऊपर की संख्या जोड़ें!",
    followups: ["What if denominators are different?", "How to multiply fractions?", "Show me a quick trick!"]
  },
  {
    keywords: ["rain", "water cycle", "clouds", "बारिश", "बादल", "जल चक्र"],
    reply_en: "When the hot sun shines on water bodies, water turns into invisible vapor ☕. It rises high where it gets chilly, condenses into fluffy clouds ☁️, and when heavy, showers down as refreshing rain! 🌧️",
    reply_hi: "जब तेज धूप पानी पर पड़ती है, तो पानी भाप बनकर ऊपर उठता है और बादलों का रूप ले लेता है ☁️। भारी होने पर यह बारिश बनकर बरसता है! 🌧️",
    followups: ["Why is sea water salty?", "How do we harvest rainwater?"]
  }
];

export const mockProgressData = {
  overall_mastery: 73,
  quizzes_completed: 44,
  total_questions_solved: 220,
  average_accuracy: 80,
  streak_history: [
    { day: "Mon", date: "Aug 10", completed: true, xp: 120 },
    { day: "Tue", date: "Aug 11", completed: true, xp: 150 },
    { day: "Wed", date: "Aug 12", completed: true, xp: 210 },
    { day: "Thu", date: "Aug 13", completed: true, xp: 180 },
    { day: "Fri", date: "Aug 14", completed: true, xp: 260 },
    { day: "Sat", date: "Aug 15", completed: true, xp: 150, today: true },
    { day: "Sun", date: "Aug 16", completed: false, xp: 0 }
  ],
  subject_mastery: [
    { name: "General Knowledge", name_hi: "सामान्य ज्ञान", percentage: 80, color: "bg-amber-500", icon: "landmark" },
    { name: "Mathematics", name_hi: "गणित", percentage: 72, color: "bg-emerald-500", icon: "calculator" },
    { name: "Science", name_hi: "विज्ञान", percentage: 68, color: "bg-sky-500", icon: "flask-conical" }
  ]
};
