/**
 * Quest AI Tutor Chat Modal Component for Questify
 */

export function renderAITutorModal(state) {
  const { aiChatHistory, currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  const quickPrompts = isHi ? [
    "पौधे धूप से खाना कैसे बनाते हैं?",
    "भिन्न (Fractions) को आसानी से कैसे जोड़ें?",
    "बारिश कैसे होती है?",
    "25 × 25 की वैदिक गणित ट्रिक बताओ"
  ] : [
    "Why do plants need sunlight?",
    "How to add fractions easily?",
    "How does the water cycle make rain?",
    "Show me a quick trick for 25 × 25"
  ];

  return `
    <div id="ai-tutor-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      
      <div class="card-rural bg-white dark:bg-slate-900 w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border-2 border-slate-300 dark:border-slate-700 overflow-hidden">
        
        <!-- Header -->
        <div class="px-6 py-4 bg-gradient-to-r from-violet-600 to-indigo-600 text-white flex items-center justify-between">
          <div class="flex items-center gap-3">
            <div class="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-2xl shadow-inner animate-mascot">
              🤖
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-game text-xl font-bold">${isHi ? 'क्वेस्ट AI शिक्षक' : 'Quest AI Tutor'}</h3>
                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/20 text-white">
                  24/7 Companion
                </span>
              </div>
              <p class="text-xs text-violet-100 font-medium">
                ${isHi ? 'सरल उदाहरणों के साथ कोई भी शंका पूछें' : 'Ask any doubt in simple, intuitive language'}
              </p>
            </div>
          </div>

          <button id="btn-close-ai-modal" class="w-8 h-8 rounded-full bg-white/15 hover:bg-white/30 text-white flex items-center justify-center font-bold text-sm transition-all">
            ✕
          </button>
        </div>

        <!-- Chat Message Stream -->
        <div id="ai-chat-messages" class="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-slate-950/50 min-h-[300px] max-h-[420px]">
          
          <!-- Welcome Message -->
          <div class="flex items-start gap-3">
            <div class="w-8 h-8 shrink-0 rounded-xl bg-violet-100 dark:bg-violet-900 text-violet-700 dark:text-violet-300 flex items-center justify-center text-base">
              🤖
            </div>
            <div class="speech-bubble p-4 text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 shadow-sm max-w-lg bg-white dark:bg-slate-800">
              <p class="leading-relaxed">
                ${isHi 
                  ? 'नमस्ते प्यारे विद्यार्थी! मैं तुम्हारा "क्वेस्ट AI" शिक्षक हूँ। मुझसे गणित, विज्ञान या सामान्य ज्ञान का कोई भी सवाल पूछो!'
                  : 'Hello curious learner! I am your Quest AI tutor. Ask me any concept you find tricky in Math, Science, or General Knowledge!'}
              </p>
            </div>
          </div>

          <!-- Dynamic Chat History -->
          ${aiChatHistory.map((msg, idx) => {
            const isUser = msg.sender === 'user';
            if (isUser) {
              return `
                <div class="flex items-end justify-end gap-2">
                  <div class="p-3.5 rounded-2xl rounded-br-none bg-emerald-600 text-white text-xs sm:text-sm font-medium shadow-sm max-w-md">
                    ${msg.text}
                  </div>
                  <div class="w-7 h-7 shrink-0 rounded-lg bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-300 flex items-center justify-center text-xs font-bold font-game">
                    You
                  </div>
                </div>
              `;
            } else {
              return `
                <div class="flex items-start gap-3">
                  <div class="w-8 h-8 shrink-0 rounded-xl bg-violet-100 dark:bg-violet-900 text-violet-700 dark:text-violet-300 flex items-center justify-center text-base">
                    🤖
                  </div>
                  <div class="speech-bubble p-4 text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 shadow-sm max-w-lg space-y-2 bg-white dark:bg-slate-800">
                    <p class="leading-relaxed">${msg.text}</p>
                    <button class="btn-ai-msg-speak text-xs font-bold text-violet-600 dark:text-violet-400 hover:underline flex items-center gap-1" data-msg-index="${idx}">
                      <span>🔊</span> <span>${isHi ? 'उत्तर सुनें' : 'Read Aloud'}</span>
                    </button>
                  </div>
                </div>
              `;
            }
          }).join('')}

        </div>

        <!-- Quick Prompt Chips -->
        <div class="px-6 py-2.5 bg-slate-100/70 dark:bg-slate-800/70 border-t border-slate-200 dark:border-slate-700 flex items-center gap-2 overflow-x-auto">
          <span class="text-[11px] font-bold text-slate-500 dark:text-slate-400 shrink-0">💡 ${isHi ? 'सुझाव:' : 'Try:'}</span>
          ${quickPrompts.map(prompt => `
            <button class="btn-quick-prompt shrink-0 px-3 py-1 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-violet-50 dark:hover:bg-violet-900/30 hover:border-violet-300 transition-all" data-prompt="${prompt}">
              ${prompt}
            </button>
          `).join('')}
        </div>

        <!-- Input Bar -->
        <div class="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
          <input type="text" id="ai-chat-input" placeholder="${isHi ? 'यहाँ अपना प्रश्न लिखें...' : 'Type your doubt here...'}" class="flex-1 px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:outline-none focus:border-violet-500 text-sm font-medium text-slate-800 dark:text-slate-100" />
          
          <button id="btn-send-ai-chat" class="btn-3d btn-3d-purple px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-1.5 shadow-sm">
            <span>🚀</span>
            <span>${isHi ? 'पूछें' : 'Ask'}</span>
          </button>
        </div>

      </div>

    </div>
  `;
}
