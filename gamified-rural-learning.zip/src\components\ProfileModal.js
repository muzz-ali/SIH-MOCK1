/**
 * Student Profile & Customization Modal Component for Questify
 */

export function renderProfileModal(state) {
  const { userProfile, currentLanguage, soundEnabled, darkMode } = state;
  const isHi = currentLanguage === 'hi';

  const avatarChoices = [
    { id: 'peacock_hero', name: 'Peacock Hero', icon: '🦚' },
    { id: 'tiger_champion', name: 'Tiger Champion', icon: '🐯' },
    { id: 'elephant_sage', name: 'Elephant Sage', icon: '🐘' },
    { id: 'squirrel_speed', name: 'Squirrel Speed', icon: '🐿️' },
    { id: 'owl_scholar', name: 'Scholar', icon: '🎓' }
  ];

  return `
    <div id="profile-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      
      <div class="card-rural bg-white dark:bg-slate-900 w-full max-w-lg shadow-2xl border-2 border-slate-300 dark:border-slate-700 overflow-hidden">
        
        <!-- Header -->
        <div class="px-6 py-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <span class="text-2xl">🎓</span>
            <h3 class="font-game text-xl font-bold">${isHi ? 'विद्यार्थी प्रोफाइल' : 'Student Profile'}</h3>
          </div>
          <button id="btn-close-profile-modal" class="w-8 h-8 rounded-full bg-white/15 hover:bg-white/30 text-white flex items-center justify-center font-bold text-sm">
            ✕
          </button>
        </div>

        <div class="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          <!-- Avatar & Main Stats -->
          <div class="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <div class="w-16 h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-900 border-2 border-emerald-300 dark:border-emerald-700 flex items-center justify-center text-4xl shadow-sm">
              ${avatarChoices.find(a => a.id === userProfile.avatar)?.icon || '🦚'}
            </div>
            <div>
              <h4 class="font-game text-xl font-bold text-slate-900 dark:text-white">${userProfile.name}</h4>
              <p class="text-xs font-semibold text-emerald-700 dark:text-emerald-400">${userProfile.school}</p>
              <p class="text-xs text-slate-500 dark:text-slate-400">${userProfile.district}, ${userProfile.state} • Grade ${userProfile.grade}</p>
            </div>
          </div>

          <!-- Avatar Picker -->
          <div>
            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
              ${isHi ? 'अपना अवतार चुनें' : 'Choose Your Avatar'}
            </label>
            <div class="grid grid-cols-5 gap-2">
              ${avatarChoices.map(av => `
                <button class="btn-select-avatar p-2.5 rounded-2xl border-2 text-2xl flex flex-col items-center gap-1 transition-all ${userProfile.avatar === av.id ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-500 shadow-md scale-105' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:bg-slate-50'}" data-avatar-id="${av.id}">
                  <span>${av.icon}</span>
                  <span class="text-[9px] font-bold text-slate-600 dark:text-slate-300 truncate w-full text-center">${av.name.split(' ')[0]}</span>
                </button>
              `).join('')}
            </div>
          </div>

          <!-- Preferences & Theme Options -->
          <div class="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700">
            <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">${isHi ? 'सेटिंग्स एवं थीम' : 'Settings & Theme'}</p>
            
            <!-- Sound Toggle -->
            <div class="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <div class="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                <span>🔊</span>
                <span>${isHi ? 'गेम साउंड व वॉयस नैरेटर' : 'Sound Effects & Voice Narration'}</span>
              </div>
              <button id="modal-btn-sound" class="px-3 py-1 rounded-lg text-xs font-bold ${soundEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300'}">
                ${soundEnabled ? 'ON' : 'OFF'}
              </button>
            </div>

            <!-- Dark / Light Mode Toggle -->
            <div class="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <div class="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                <span>${darkMode ? '🌙' : '☀️'}</span>
                <span>${isHi ? 'डार्क / लाइट मोड' : 'Dark / Light Theme'}</span>
              </div>
              <button id="modal-btn-theme" class="px-3 py-1 rounded-lg text-xs font-bold ${darkMode ? 'bg-indigo-600 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300'}">
                ${darkMode ? 'DARK' : 'LIGHT'}
              </button>
            </div>

          </div>

          <!-- Save Button -->
          <button id="btn-save-profile" class="btn-3d btn-3d-primary w-full py-3.5 rounded-2xl text-sm font-bold shadow-md">
            ${isHi ? 'सेटिंग्स सुरक्षित करें' : 'Save & Close'}
          </button>

        </div>

      </div>

    </div>
  `;
}
