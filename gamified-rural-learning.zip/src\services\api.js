/**
 * Dedicated API Service Layer strictly implementing docs/API.md
 * Integrates with FastAPI backend or seamless Mock Service with LocalStorage persistence.
 */

import {
  mockUserProfile,
  mockSubjects,
  mockDailyChallenge,
  mockQuestionBank,
  mockLeaderboard,
  mockAITutorResponses,
  mockProgressData
} from './mockData.js';

class ApiService {
  constructor() {
    this.baseUrl = window.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';
    this.useMock = true; // Auto-fallback or simulated mode
    this.initLocalStorage();
  }

  initLocalStorage() {
    if (!localStorage.getItem('vidyodaya_profile')) {
      localStorage.setItem('vidyodaya_profile', JSON.stringify(mockUserProfile));
    }
    if (!localStorage.getItem('vidyodaya_daily_challenge')) {
      localStorage.setItem('vidyodaya_daily_challenge', JSON.stringify(mockDailyChallenge));
    }
  }

  async getProfile() {
    if (this.useMock) {
      await this.simulateDelay(150);
      const profile = JSON.parse(localStorage.getItem('vidyodaya_profile') || JSON.stringify(mockUserProfile));
      return profile;
    }
    const res = await fetch(`${this.baseUrl}/user/profile`);
    if (!res.ok) throw new Error("Failed to fetch profile");
    return await res.json();
  }

  async updateProfile(updates) {
    if (this.useMock) {
      await this.simulateDelay(150);
      const current = await this.getProfile();
      const updated = { ...current, ...updates };
      localStorage.setItem('vidyodaya_profile', JSON.stringify(updated));
      return updated;
    }
    const res = await fetch(`${this.baseUrl}/user/profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    return await res.json();
  }

  async getSubjects() {
    if (this.useMock) {
      await this.simulateDelay(120);
      return mockSubjects;
    }
    const res = await fetch(`${this.baseUrl}/subjects`);
    if (!res.ok) throw new Error("Failed to fetch subjects");
    return await res.json();
  }

  async getDailyChallenge() {
    if (this.useMock) {
      await this.simulateDelay(120);
      const challenge = JSON.parse(localStorage.getItem('vidyodaya_daily_challenge') || JSON.stringify(mockDailyChallenge));
      return challenge;
    }
    const res = await fetch(`${this.baseUrl}/daily-challenge`);
    if (!res.ok) throw new Error("Failed to fetch daily challenge");
    return await res.json();
  }

  async generateQuiz(subjectId = 'math', difficulty = 'medium', mode = 'practice') {
    if (this.useMock) {
      await this.simulateDelay(200);
      const bank = mockQuestionBank[subjectId] || mockQuestionBank.math;
      // Return 5 questions matching docs/API.md
      const questions = bank.map(q => ({
        id: q.id,
        question: q.question,
        question_hi: q.question_hi,
        options: q.options,
        options_hi: q.options_hi,
        topic: q.topic,
        hint: q.hint
      }));

      const subjectObj = mockSubjects.find(s => s.id === subjectId) || mockSubjects[0];

      return {
        quiz_id: `qz_${Date.now()}`,
        subject_id: subjectId,
        subject_name: subjectObj.name,
        subject_name_hi: subjectObj.name_hi,
        total_questions: questions.length,
        time_limit_seconds: 300,
        xp_reward: mode === 'daily' ? 150 : 100,
        questions: questions
      };
    }

    const res = await fetch(`${this.baseUrl}/quiz/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject_id: subjectId, difficulty, mode })
    });
    if (!res.ok) throw new Error("Failed to generate quiz");
    return await res.json();
  }

  async submitQuiz(quizId, subjectId, userAnswers, isDailyChallenge = false) {
    if (this.useMock) {
      await this.simulateDelay(300);
      const bank = mockQuestionBank[subjectId] || mockQuestionBank.math;
      let score = 0;
      const breakdown = [];
      const weakTopics = [];
      const strongTopics = [];

      userAnswers.forEach(ans => {
        const originalQ = bank.find(q => q.id === ans.question_id);
        if (originalQ) {
          const isCorrect = ans.selected_option_index === originalQ.correct_index;
          if (isCorrect) {
            score++;
            if (!strongTopics.includes(originalQ.topic)) strongTopics.push(originalQ.topic);
          } else {
            if (!weakTopics.includes(originalQ.topic)) weakTopics.push(originalQ.topic);
          }
          breakdown.push({
            question_id: originalQ.id,
            question_text: originalQ.question,
            question_text_hi: originalQ.question_hi,
            is_correct: isCorrect,
            correct_option_index: originalQ.correct_index,
            correct_option_text: originalQ.options[originalQ.correct_index],
            correct_option_text_hi: originalQ.options_hi[originalQ.correct_index],
            user_option_index: ans.selected_option_index,
            explanation: originalQ.explanation,
            topic: originalQ.topic
          });
        }
      });

      const total = breakdown.length || 5;
      const accuracy = Math.round((score / total) * 100);
      const baseXP = score * 20;
      const bonusXP = isDailyChallenge ? 50 : (accuracy === 100 ? 30 : 10);
      const xpEarned = baseXP + bonusXP;

      // Update student profile in localStorage
      const profile = await this.getProfile();
      const oldXp = profile.xp;
      const newTotalXp = oldXp + xpEarned;
      const currentLevel = profile.level;
      const newLevel = Math.floor(newTotalXp / 500) + 1;
      const leveledUp = newLevel > currentLevel;

      profile.xp = newTotalXp;
      profile.level = newLevel;
      profile.current_level_xp = newTotalXp % 500;
      profile.total_level_xp_needed = 500;
      profile.xp_to_next_level = 500 - profile.current_level_xp;

      if (isDailyChallenge) {
        const challenge = await this.getDailyChallenge();
        challenge.is_completed = true;
        localStorage.setItem('vidyodaya_daily_challenge', JSON.stringify(challenge));
        profile.streak_days += 1;
        profile.streak_active_today = true;
      }

      localStorage.setItem('vidyodaya_profile', JSON.stringify(profile));

      return {
        submission_id: `sub_${Date.now()}`,
        score: score,
        total_questions: total,
        accuracy_percentage: accuracy,
        xp_earned: xpEarned,
        bonus_xp: bonusXP,
        new_total_xp: newTotalXp,
        leveled_up: leveledUp,
        new_level: newLevel,
        streak_updated: isDailyChallenge,
        new_streak_days: profile.streak_days,
        ai_analysis: {
          strong_topics: strongTopics.length ? strongTopics : ["Core Fundamentals"],
          weak_topics: weakTopics.length ? weakTopics : ["Speed & Time Optimization"],
          feedback_text: accuracy >= 80 
            ? `शानदार प्रदर्शन (Spectacular performance)! You showed master-level confidence in ${strongTopics[0] || 'your concepts'}. Keep shining!`
            : `बहुत अच्छा प्रयास (Great effort)! You are growing rapidly. Let's spend 3 minutes mastering ${weakTopics[0] || 'the questions you missed'}!`,
          recommended_quiz: {
            subject_id: subjectId,
            topic: weakTopics[0] || "Advanced Practice",
            title: `Quick Booster: ${weakTopics[0] || 'Next Challenge'}`
          }
        },
        question_breakdown: breakdown
      };
    }

    const res = await fetch(`${this.baseUrl}/quiz/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ quiz_id: quizId, answers: userAnswers })
    });
    if (!res.ok) throw new Error("Failed to submit quiz");
    return await res.json();
  }

  async getLeaderboard(scope = 'village') {
    if (this.useMock) {
      await this.simulateDelay(150);
      return mockLeaderboard[scope] || mockLeaderboard.village;
    }
    const res = await fetch(`${this.baseUrl}/leaderboard?scope=${scope}`);
    if (!res.ok) throw new Error("Failed to fetch leaderboard");
    return await res.json();
  }

  async getProgress() {
    if (this.useMock) {
      await this.simulateDelay(150);
      return mockProgressData;
    }
    const res = await fetch(`${this.baseUrl}/progress`);
    if (!res.ok) throw new Error("Failed to fetch progress");
    return await res.json();
  }

  async askAITutor(query, language = 'en', grade = 6) {
    if (this.useMock) {
      await this.simulateDelay(350);
      const lowerQ = query.toLowerCase();
      const matched = mockAITutorResponses.find(item => 
        item.keywords.some(k => lowerQ.includes(k))
      );

      if (matched) {
        return {
          reply_text: language === 'hi' ? matched.reply_hi : matched.reply_en,
          reply_text_en: matched.reply_en,
          reply_text_hi: matched.reply_hi,
          suggested_followups: matched.followups
        };
      }

      // Default friendly rural AI response
      const defaultEn = `That's a wonderful curiosity! In village science and nature, everything is connected like a banyan tree with deep roots. When you explore ${query}, remember that asking questions is the first superpower of every great scientist! Let's solve a 2-minute quick quiz on this topic to see it in action! 🌟`;
      const defaultHi = `यह बहुत ही सुंदर सवाल है! विज्ञान और प्रकृति में हर चीज़ एक बड़े बरगद के पेड़ की तरह आपस में जुड़ी होती है। जब आप "${query}" के बारे में सोचते हैं, तो याद रखें कि सवाल पूछना ही एक महान वैज्ञानिक की पहली पहचान है! आइए इस पर 2 मिनट का मजेदार अभ्यास करें! 🌟`;

      return {
        reply_text: language === 'hi' ? defaultHi : defaultEn,
        reply_text_en: defaultEn,
        reply_text_hi: defaultHi,
        suggested_followups: ["Tell me more with an example", "Give me a practice question", "Explain in simple Hindi"]
      };
    }

    const res = await fetch(`${this.baseUrl}/ai/tutor`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ student_query: query, language, grade })
    });
    if (!res.ok) throw new Error("Failed to consult AI tutor");
    return await res.json();
  }

  simulateDelay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const API = new ApiService();
