/**
 * Gamified Welcome Hero Banner Component for Questify
 */

export function renderHeroBanner(state) {
  const { userProfile, currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  const greetings = {
    hi: {
      title: `नमस्ते, ${userProfile.name.split(' ')[0]}! 🌟`,
      sub: "आज कुछ नया सीखते हैं और अपनी कक्षा में नंबर 1 बनते हैं!",
      mascotQuote: "आज गणित, विज्ञान और सामान्य ज्ञान में 150 बोनस XP सक्रिय है! तैयार हो?",
      dailyTasks: "आज के दैनिक लक्ष्य",
      task1: "दैनिक चुनौती पूरा करें (+150 XP)",
      task2: "गणित या विज्ञान में 5 प्रश्न हल करें",
      task3: "अपनी 5 दिन की लपट (Streak) बनाए रखें",
      ctaDaily: "⚡ आज की चुनौती खेलें",
      ctaSubjects: "📚 विषय चुनें"
    },
    en: {
      title: `Welcome to Questify, ${userProfile.name.split(' ')[0]}! 🌟`,
      sub: "Let's conquer new quests in Mathematics, Science & General Knowledge today!",
      mascotQuote: "Special 150 Bonus XP active today across all subjects! Ready to rise?",
      dailyTasks: "Today's Quest Goals",
      task1: "Complete Daily Challenge (+150 XP)",
      task2: "Solve 5 questions in Math or Science",
      task3: "Maintain your 5-Day Streak 🔥",
      ctaDaily: "⚡ Play Daily Quest",
      ctaSubjects: "📚 Explore Subjects"
    }
  };

  const t = isHi ? greetings.hi : greetings.en;

  return `
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-700 to-sky-800 text-white shadow-xl p-6 sm:p-8 mb-8 border-4 border-emerald-500/30">
      
      <!-- Decorative Background Elements -->
      <div class="absolute -right-16 -bottom-16 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
      <div class="absolute right-1/3 -top-16 w-48 h-48 bg-amber-400/20 rounded-full blur-xl pointer-events-none"></div>

      <div class="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        
        <!-- Left: Personalized Greeting & Call to Actions -->
        <div class="lg:col-span-7 space-y-4">
          <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-md border border-white/20 text-emerald-100 text-xs font-bold tracking-wide uppercase">
            <span>✨</span>
            <span>${userProfile.school} • Grade ${userProfile.grade}</span>
          </div>

          <h1 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-game text-white drop-shadow-sm leading-tight">
            ${t.title}
          </h1>
          
          <p class="text-emerald-100 text-sm sm:text-base max-w-xl font-medium leading-relaxed">
            ${t.sub}
          </p>

          <!-- Action Buttons -->
          <div class="flex flex-wrap gap-3 pt-2">
            <button class="btn-3d btn-3d-amber px-5 py-3 rounded-2xl text-sm font-bold flex items-center gap-2 shadow-lg" id="hero-btn-daily">
              <span>⚡</span>
              <span>${t.ctaDaily}</span>
            </button>
            <button class="btn-3d btn-3d-white px-5 py-3 rounded-2xl text-sm font-bold flex items-center gap-2 shadow-lg text-slate-800 dark:text-white" id="hero-btn-subjects">
              <span>📚</span>
              <span>${t.ctaSubjects}</span>
            </button>
          </div>
        </div>

        <!-- Right: Quest Badge & Daily Tasks Widget -->
        <div class="lg:col-span-5 bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 shadow-inner">
          
          <!-- Quest Badge with Speech Bubble -->
          <div class="flex items-start gap-4 mb-4">
            <div class="w-14 h-14 shrink-0 rounded-2xl bg-amber-400 text-slate-900 text-3xl flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform">
              <span class="animate-mascot select-none">✨</span>
            </div>
            <div class="bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 p-3 rounded-2xl rounded-tl-none shadow-md text-xs sm:text-sm font-medium border border-slate-100 dark:border-slate-700 relative">
              <p class="leading-snug">${t.mascotQuote}</p>
              <button class="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline mt-1.5 flex items-center gap-1" id="btn-hero-speak-quote">
                <span>🔊</span> <span>${isHi ? 'सुनें (Listen)' : 'Read Aloud'}</span>
              </button>
            </div>
          </div>

          <!-- Mini Quest Checklist -->
          <div class="space-y-2 pt-1 border-t border-white/15">
            <p class="text-xs font-bold uppercase tracking-wider text-emerald-200">${t.dailyTasks}</p>
            <div class="flex items-center gap-2 text-xs font-medium text-white/90">
              <span class="text-emerald-300">✔</span>
              <span class="line-through text-white/60">${t.task3}</span>
            </div>
            <div class="flex items-center gap-2 text-xs font-medium text-white/90">
              <span class="text-amber-300">⏳</span>
              <span>${t.task1}</span>
            </div>
            <div class="flex items-center gap-2 text-xs font-medium text-white/90">
              <span class="text-amber-300">⏳</span>
              <span>${t.task2}</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  `;
}
