/**
 * Responsive Flexbox Header & Navigation Component for Questify
 */

export function renderHeader(state) {
  const { userProfile, currentView, currentLanguage, darkMode, soundEnabled } = state;
  const isHi = currentLanguage === 'hi';

  return `
    <header class="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b-2 border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
          
          <!-- Logo & Brand (Questify) -->
          <div class="flex items-center gap-3 cursor-pointer select-none" id="nav-logo-btn">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-sky-500 p-1 flex items-center justify-center shadow-md shadow-emerald-500/20 transform hover:scale-105 transition-transform">
              <span class="text-2xl font-game font-extrabold text-white select-none">Q</span>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="font-game text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-600 dark:from-emerald-400 dark:via-teal-300 dark:to-sky-400 bg-clip-text text-transparent">
                  Questify
                </span>
              </div>
              <p class="text-xs text-slate-500 dark:text-slate-400 font-medium -mt-1 hidden sm:block">
                ${isHi ? 'स्मार्ट गेम-आधारित शिक्षण' : 'Gamified Learning Platform'}
              </p>
            </div>
          </div>

          <!-- Desktop Flex Navigation Links -->
          <nav class="hidden lg:flex items-center gap-1.5 bg-slate-100/80 dark:bg-slate-800/80 p-1.5 rounded-2xl border border-slate-200/80 dark:border-slate-700">
            <button class="nav-item-btn flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${currentView === 'dashboard' ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700'}" data-view="dashboard">
              <span>🏠</span>
              <span>${isHi ? 'डैशबोर्ड' : 'Home'}</span>
            </button>
            <button class="nav-item-btn flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${currentView === 'subjects' ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700'}" data-view="subjects">
              <span>📚</span>
              <span>${isHi ? 'विषय' : 'Subjects'}</span>
            </button>
            <button class="nav-item-btn flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all relative ${currentView === 'daily' ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700'}" data-view="daily">
              <span class="text-amber-500">⚡</span>
              <span>${isHi ? 'दैनिक चुनौती' : 'Daily Quest'}</span>
              <span class="w-2 h-2 rounded-full bg-amber-500 animate-ping absolute top-1.5 right-1.5"></span>
            </button>
            <button class="nav-item-btn flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${currentView === 'leaderboard' ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700'}" data-view="leaderboard">
              <span>🏆</span>
              <span>${isHi ? 'लीडरबोर्ड' : 'Rankings'}</span>
            </button>
            <button class="nav-item-btn flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${currentView === 'progress' ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700'}" data-view="progress">
              <span>📊</span>
              <span>${isHi ? 'प्रगति' : 'Progress'}</span>
            </button>
            <button class="nav-item-btn flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all bg-gradient-to-r from-violet-500 to-indigo-500 text-white shadow-sm hover:opacity-95" id="btn-open-ai-tutor">
              <span>🤖</span>
              <span>${isHi ? 'क्वेस्ट AI' : 'Quest AI'}</span>
            </button>
          </nav>

          <!-- Top Gamified Status Badges & Utilities -->
          <div class="flex items-center gap-2 sm:gap-3">
            
            <!-- Streak Flame Badge -->
            <div class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400 font-game font-bold text-sm shadow-sm cursor-pointer hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-all" id="badge-streak" title="Daily Learning Streak">
              <span class="text-base animate-flame">🔥</span>
              <span>${userProfile.streak_days} ${isHi ? 'दिन' : 'Days'}</span>
            </div>

            <!-- XP Count & Level Badge -->
            <div class="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 font-game font-bold text-sm shadow-sm cursor-pointer hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-all" id="badge-xp" title="Total XP & Level">
              <span class="text-base">⚡</span>
              <span>${userProfile.xp} XP</span>
              <span class="px-1.5 py-0.5 rounded-md bg-emerald-600 text-white text-[11px] font-bold">
                Lvl ${userProfile.level}
              </span>
            </div>

            <!-- Language Switcher Pill -->
            <button id="btn-lang-toggle" class="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-all" title="Change Language">
              <span>🌐</span>
              <span class="uppercase">${currentLanguage}</span>
            </button>

            <!-- Sound / Voice Audio FX Toggle -->
            <button id="btn-sound-toggle" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-sm" title="${soundEnabled ? 'Mute Sounds & Voice' : 'Enable Audio'}">
              <span>${soundEnabled ? '🔊' : '🔇'}</span>
            </button>

            <!-- Dark / Light Mode Toggle Button -->
            <button id="btn-theme-toggle" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-amber-400 transition-all text-sm" title="${darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}">
              <span>${darkMode ? '☀️' : '🌙'}</span>
            </button>

            <!-- Student Profile Avatar Button -->
            <button id="btn-profile-open" class="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border-2 border-slate-300 dark:border-slate-700 shadow-sm transition-all">
              <div class="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 border border-emerald-300 dark:border-emerald-700 flex items-center justify-center text-lg">
                🎓
              </div>
              <div class="hidden xl:block text-left">
                <p class="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight">${userProfile.name.split(' ')[0]}</p>
                <p class="text-[10px] font-medium text-emerald-600 dark:text-emerald-400">Class ${userProfile.grade}th</p>
              </div>
            </button>

            <!-- Mobile Hamburger Toggle -->
            <button id="btn-mobile-menu" class="lg:hidden p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 text-lg">
              ☰
            </button>

          </div>

        </div>
      </div>

      <!-- Mobile Navigation Drawer -->
      <div id="mobile-nav-drawer" class="hidden lg:hidden bg-white dark:bg-slate-900 border-b-2 border-slate-200 dark:border-slate-800 px-4 pt-2 pb-4 space-y-2">
        <div class="grid grid-cols-2 gap-2 pt-2">
          <button class="nav-item-btn flex items-center gap-2 p-3 rounded-xl text-sm font-bold ${currentView === 'dashboard' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200'}" data-view="dashboard">
            <span>🏠</span>
            <span>${isHi ? 'डैशबोर्ड' : 'Home'}</span>
          </button>
          <button class="nav-item-btn flex items-center gap-2 p-3 rounded-xl text-sm font-bold ${currentView === 'subjects' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200'}" data-view="subjects">
            <span>📚</span>
            <span>${isHi ? 'विषय' : 'Subjects'}</span>
          </button>
          <button class="nav-item-btn flex items-center gap-2 p-3 rounded-xl text-sm font-bold ${currentView === 'daily' ? 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-300' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200'}" data-view="daily">
            <span>⚡</span>
            <span>${isHi ? 'दैनिक चुनौती' : 'Daily Quest'}</span>
          </button>
          <button class="nav-item-btn flex items-center gap-2 p-3 rounded-xl text-sm font-bold ${currentView === 'leaderboard' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200'}" data-view="leaderboard">
            <span>🏆</span>
            <span>${isHi ? 'लीडरबोर्ड' : 'Rankings'}</span>
          </button>
          <button class="nav-item-btn flex items-center gap-2 p-3 rounded-xl text-sm font-bold ${currentView === 'progress' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300' : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200'}" data-view="progress">
            <span>📊</span>
            <span>${isHi ? 'प्रगति' : 'Progress'}</span>
          </button>
          <button class="flex items-center gap-2 p-3 rounded-xl text-sm font-bold bg-violet-600 text-white" id="mobile-btn-open-ai-tutor">
            <span>🤖</span>
            <span>${isHi ? 'क्वेस्ट AI' : 'Quest AI'}</span>
          </button>
        </div>
      </div>
    </header>
  `;
}
