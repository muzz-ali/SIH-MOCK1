/**
 * Daily Challenge Card Component for Questify
 */

export function renderDailyChallenge(state) {
  const { dailyChallenge, currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  if (!dailyChallenge) return '';

  const isCompleted = dailyChallenge.is_completed;

  return `
    <div class="card-rural p-6 sm:p-7 bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50 dark:from-amber-950/30 dark:via-slate-800 dark:to-orange-950/30 border-amber-300 dark:border-amber-800 border-b-amber-400 dark:border-b-amber-700 mb-8 relative overflow-hidden">
      
      <!-- Sparkle Corner Tag -->
      <div class="absolute top-0 right-0 bg-gradient-to-l from-amber-500 to-orange-500 text-white text-xs font-game font-bold px-4 py-1.5 rounded-bl-2xl shadow-sm flex items-center gap-1.5">
        <span class="animate-flame">🔥</span>
        <span>${isHi ? 'विशेष दैनिक चुनौती' : 'DAILY SPRINT'}</span>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        
        <!-- Icon & Challenge Details -->
        <div class="md:col-span-8 flex items-start gap-4">
          <div class="w-16 h-16 shrink-0 rounded-2xl ${isCompleted ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white'} flex items-center justify-center text-3xl shadow-md transform hover:rotate-6 transition-transform">
            ${isCompleted ? '🏆' : '⚡'}
          </div>

          <div class="space-y-1.5">
            <div class="flex items-center gap-2 flex-wrap">
              <h3 class="font-game text-xl sm:text-2xl font-bold text-slate-800 dark:text-slate-100">
                ${isHi ? (dailyChallenge.title_hi || dailyChallenge.title) : dailyChallenge.title}
              </h3>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700">
                +${dailyChallenge.xp_reward} XP
              </span>
            </div>
            
            <p class="text-sm text-slate-600 dark:text-slate-300 font-medium max-w-2xl">
              ${isHi ? (dailyChallenge.description_hi || dailyChallenge.description) : dailyChallenge.description}
            </p>

            <div class="flex items-center gap-4 text-xs font-semibold text-slate-500 dark:text-slate-400 pt-1">
              <span class="flex items-center gap-1">
                <span>📝</span> ${dailyChallenge.total_questions} ${isHi ? 'प्रश्न' : 'Questions'}
              </span>
              <span class="flex items-center gap-1 text-amber-700 dark:text-amber-400">
                <span>⏳</span> ${isHi ? 'समय बाकी: 7 घंटे' : 'Expires in: 7h 45m'}
              </span>
              <span class="flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                <span>🔥</span> +1 ${isHi ? 'दिन लपट' : 'Streak Day'}
              </span>
            </div>
          </div>
        </div>

        <!-- Action / Status Button -->
        <div class="md:col-span-4 flex md:justify-end">
          ${isCompleted ? `
            <div class="w-full md:w-auto text-center px-6 py-3 rounded-2xl bg-emerald-100 dark:bg-emerald-950 border-2 border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300 font-game font-bold flex items-center justify-center gap-2">
              <span class="text-xl">✅</span>
              <span>${isHi ? 'आज पूरा हो गया! (+150 XP)' : 'Completed Today! (+150 XP)'}</span>
            </div>
          ` : `
            <button class="btn-3d btn-3d-amber w-full md:w-auto px-7 py-3.5 rounded-2xl text-base font-bold flex items-center justify-center gap-2 shadow-lg pulse-active" id="btn-start-daily-challenge">
              <span>⚡</span>
              <span>${isHi ? 'चुनौती शुरू करें' : 'Start Daily Sprint'}</span>
            </button>
          `}
        </div>

      </div>
    </div>
  `;
}
