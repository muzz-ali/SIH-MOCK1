# Project Overview: Vidyodaya (Gamified Learning Platform for Rural Education)

## 1. Executive Summary
**Vidyodaya** is an interactive, gamified learning platform developed for the **Smart India Hackathon (SIH)**. The platform is designed specifically to solve core challenges faced by students in rural Indian schools (Classes 3 to 10):
- Lack of engaging, interactive digital educational content.
- High drop-off rates due to rote learning and boring interfaces.
- Intermittent internet connectivity and low-end mobile devices.
- Language barriers and early-reader literacy challenges.

## 2. Core Value Proposition
- **Playful Gamification**: Turns routine textbook learning into captivating quests with XP points, streak flames, levels, badges, and village-level leaderboards.
- **Adaptive AI Feedback ("Mitra AI")**: Evaluates student quiz performance to diagnose strong and weak topics, adjusting question difficulty and providing personalized remediation.
- **Rural-First Accessibility**:
  - **Bilingual Support**: Instant toggle between English and regional languages (Hindi, Bengali, Tamil, Telugu, Marathi).
  - **Text-to-Speech Narration**: Spoken voice read-aloud for students who struggle with reading comprehension.
  - **Ultra-Lightweight & Offline Caching**: Optimized for 2G/3G networks and offline caching via localStorage and lightweight assets.

## 3. Student Journey Flow
```
Student Login / Select Class & Language
                  ↓
          Gamified Dashboard
     (Daily Quest / Subject Quests)
                  ↓
             Quiz Arena
 (Tactile Answers / Audio TTS / Lifelines)
                  ↓
        Instant Backend Evaluation
                  ↓
        AI Diagnostic Results
  (XP Gained, Level Up, Strengths/Weaknesses,
       Personalized Remediation)
                  ↓
      Progress & Village Leaderboards
```

## 4. Key Performance Indicators (KPIs)
- **Daily Active Engagement**: Measured via streak retention and Daily Challenge completion rates.
- **Learning Efficacy**: Improvement in mastery percentage across weak topics over 7-day intervals.
- **Accessibility Index**: Zero UI layout shifts on low-end mobile devices and instant offline fallback.
