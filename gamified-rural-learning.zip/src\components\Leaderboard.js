/**
 * Multi-Level Leaderboard Component for Questify
 */

export function renderLeaderboard(state) {
  const { leaderboardData, leaderboardScope, currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  if (!leaderboardData) return '';

  const { scope_name, my_rank, top_students } = leaderboardData;
  const top3 = top_students.slice(0, 3);
  const remaining = top_students.slice(3);

  const avatarsMap = {
    owl_scholar: '🦉',
    peacock_hero: '🦚',
    tiger_champion: '🐯',
    elephant_sage: '🐘',
    squirrel_speed: '🐿️'
  };

  return `
    <div class="max-w-4xl mx-auto py-4 px-2 sm:px-4 space-y-6">
      
      <!-- Section Header -->
      <div class="flex items-center justify-between flex-wrap gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-3xl">🏆</span>
            <h2 class="text-2xl sm:text-3xl font-game font-bold text-slate-900 dark:text-white">
              ${isHi ? 'प्रतियोगिता लीडरबोर्ड' : 'Quest Champion Leaderboard'}
            </h2>
          </div>
          <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">
            ${isHi ? 'स्कूल, जिला और राष्ट्रीय स्तर पर छात्रों में आपकी रैंकिंग' : 'Compete with top learners across your school, district, and state'}
          </p>
        </div>

        <!-- Scope Switcher Tabs -->
        <div class="flex items-center gap-1.5 p-1.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm">
          <button class="btn-leaderboard-scope px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${leaderboardScope === 'village' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}" data-scope="village">
            🏫 ${isHi ? 'हमारा स्कूल' : 'My School'}
          </button>
          <button class="btn-leaderboard-scope px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${leaderboardScope === 'district' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}" data-scope="district">
            📍 ${isHi ? 'जिला' : 'District'}
          </button>
          <button class="btn-leaderboard-scope px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${leaderboardScope === 'all_india' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}" data-scope="all_india">
            🇮🇳 ${isHi ? 'अखिल भारतीय' : 'All India'}
          </button>
        </div>
      </div>

      <!-- Scope Location Subtitle Banner -->
      <div class="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs font-bold text-emerald-900 dark:text-emerald-300">
        <span class="flex items-center gap-1.5">
          <span>🌟</span> ${isHi ? 'वर्तमान क्षेत्र:' : 'Active Scope:'} <strong class="text-emerald-950 dark:text-emerald-200">${scope_name}</strong>
        </span>
        <span class="text-emerald-700 dark:text-emerald-400">${isHi ? 'प्रतिदिन अपडेट होता है' : 'Updated Live Daily'}</span>
      </div>

      <!-- Top 3 Podium Cards -->
      <div class="grid grid-cols-3 gap-3 sm:gap-4 items-end pt-6 pb-2">
        
        <!-- Rank 2: Silver -->
        ${top3[1] ? `
          <div class="card-rural p-3 sm:p-5 bg-gradient-to-t from-slate-100 to-white dark:from-slate-800 dark:to-slate-700 border-slate-300 dark:border-slate-600 text-center flex flex-col items-center justify-end h-56 sm:h-64 relative">
            <div class="absolute -top-4 w-9 h-9 rounded-full bg-slate-300 dark:bg-slate-600 border-2 border-white dark:border-slate-800 flex items-center justify-center font-game font-extrabold text-slate-800 dark:text-white shadow-md">
              2
            </div>
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-100 dark:bg-slate-700 border-2 border-slate-300 dark:border-slate-600 flex items-center justify-center text-3xl shadow-sm mb-2">
              ${avatarsMap[top3[1].avatar] || '🐯'}
            </div>
            <h4 class="font-game font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100 truncate w-full">${top3[1].student_name}</h4>
            <p class="text-[10px] text-slate-500 dark:text-slate-400 truncate w-full">${top3[1].school}</p>
            <div class="mt-2 px-2.5 py-1 rounded-xl bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-100 font-game font-bold text-xs">
              ⚡ ${top3[1].xp} XP
            </div>
          </div>
        ` : ''}

        <!-- Rank 1: Gold (Center & Tallest) -->
        ${top3[0] ? `
          <div class="card-rural p-4 sm:p-6 bg-gradient-to-t from-amber-100 via-amber-50 to-white dark:from-amber-950/40 dark:via-slate-800 dark:to-slate-700 border-amber-300 dark:border-amber-700 text-center flex flex-col items-center justify-end h-64 sm:h-72 relative shadow-lg">
            <div class="absolute -top-5 w-11 h-11 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 border-2 border-white dark:border-slate-800 flex items-center justify-center font-game font-extrabold text-amber-950 text-base shadow-md animate-bounce">
              👑 1
            </div>
            <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-amber-100 dark:bg-amber-900/50 border-2 border-amber-400 dark:border-amber-600 flex items-center justify-center text-4xl shadow-md mb-2">
              ${avatarsMap[top3[0].avatar] || '🦚'}
            </div>
            <h4 class="font-game font-bold text-sm sm:text-base text-slate-900 dark:text-white truncate w-full">${top3[0].student_name}</h4>
            <p class="text-[11px] text-amber-800 dark:text-amber-300 font-medium truncate w-full">${top3[0].school}</p>
            <div class="mt-2 px-3.5 py-1.5 rounded-xl bg-amber-400 text-amber-950 font-game font-bold text-xs sm:text-sm shadow-sm">
              ⚡ ${top3[0].xp} XP
            </div>
          </div>
        ` : ''}

        <!-- Rank 3: Bronze -->
        ${top3[2] ? `
          <div class="card-rural p-3 sm:p-5 bg-gradient-to-t from-orange-50 to-white dark:from-orange-950/40 dark:to-slate-700 border-amber-200 dark:border-amber-800 text-center flex flex-col items-center justify-end h-48 sm:h-56 relative">
            <div class="absolute -top-4 w-9 h-9 rounded-full bg-amber-600 text-white border-2 border-white dark:border-slate-800 flex items-center justify-center font-game font-extrabold text-xs shadow-md">
              3
            </div>
            <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-orange-100 dark:bg-orange-900/50 border-2 border-amber-300 dark:border-amber-700 flex items-center justify-center text-2xl shadow-sm mb-2">
              ${avatarsMap[top3[2].avatar] || '🐘'}
            </div>
            <h4 class="font-game font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100 truncate w-full">${top3[2].student_name}</h4>
            <p class="text-[10px] text-slate-500 dark:text-slate-400 truncate w-full">${top3[2].school}</p>
            <div class="mt-2 px-2.5 py-1 rounded-xl bg-orange-200 dark:bg-orange-900 text-orange-950 dark:text-orange-200 font-game font-bold text-xs">
              ⚡ ${top3[2].xp} XP
            </div>
          </div>
        ` : ''}

      </div>

      <!-- Sticky Personal Rank Banner -->
      <div class="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between shadow-lg border-2 border-emerald-400">
        <div class="flex items-center gap-3.5">
          <div class="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center font-game font-extrabold text-xl">
            #${my_rank.rank}
          </div>
          <div>
            <span class="text-[10px] uppercase font-bold text-emerald-200">${isHi ? 'आपकी वर्तमान स्थिति' : 'Your Current Standing'}</span>
            <h4 class="font-game text-base sm:text-lg font-bold">${my_rank.student_name}</h4>
          </div>
        </div>

        <div class="flex items-center gap-4">
          <div class="text-right hidden sm:block">
            <p class="text-xs text-emerald-200">🔥 ${my_rank.streak} ${isHi ? 'दिन लपट' : 'Day Streak'}</p>
            <p class="text-xs font-bold text-emerald-100">Level ${my_rank.level}</p>
          </div>
          <div class="px-4 py-2 rounded-xl bg-white text-emerald-800 font-game font-bold text-sm shadow-md">
            ⚡ ${my_rank.xp} XP
          </div>
        </div>
      </div>

      <!-- Complete Ranking List Table -->
      <div class="card-rural bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          <span>${isHi ? 'स्थान व छात्र' : 'Rank & Student'}</span>
          <span>${isHi ? 'कुल XP एवं स्तर' : 'Total XP & Level'}</span>
        </div>

        <div class="divide-y divide-slate-100 dark:divide-slate-700">
          ${remaining.map(st => `
            <div class="px-6 py-3.5 flex items-center justify-between hover:bg-slate-50/80 dark:hover:bg-slate-700/50 transition-colors">
              <div class="flex items-center gap-3.5">
                <span class="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-game font-bold text-xs flex items-center justify-center">
                  ${st.rank}
                </span>
                <div class="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-xl">
                  ${avatarsMap[st.avatar] || '🎓'}
                </div>
                <div>
                  <h5 class="font-bold text-sm text-slate-800 dark:text-slate-100 font-game">${st.student_name}</h5>
                  <p class="text-xs text-slate-400 font-medium">${st.school}</p>
                </div>
              </div>

              <div class="flex items-center gap-3">
                <span class="hidden sm:inline-flex px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-medium">
                  Lvl ${st.level}
                </span>
                <span class="font-game font-bold text-sm text-emerald-700 dark:text-emerald-400">
                  ⚡ ${st.xp} XP
                </span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

    </div>
  `;
}
