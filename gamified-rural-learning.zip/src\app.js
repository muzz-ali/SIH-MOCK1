/**
 * Questify - Main SPA Application Controller & State Manager
 */

import { API } from './services/api.js';
import { SoundFX } from './services/soundEffects.js';
import { renderHeader } from './components/Header.js';
import { renderHeroBanner } from './components/HeroBanner.js';
import { renderDailyChallenge } from './components/DailyChallenge.js';
import { renderSubjectCards } from './components/SubjectCards.js';
import { renderQuizScreen } from './components/QuizScreen.js';
import { renderQuizResult } from './components/QuizResult.js';
import { renderLeaderboard } from './components/Leaderboard.js';
import { renderProgressScreen } from './components/ProgressScreen.js';
import { renderAITutorModal } from './components/AITutorModal.js';
import { renderProfileModal } from './components/ProfileModal.js';
import { renderFooter } from './components/Footer.js';

class App {
  constructor() {
    this.state = {
      userProfile: null,
      subjects: [],
      dailyChallenge: null,
      leaderboardData: null,
      leaderboardScope: 'village',
      progressData: null,
      currentView: 'dashboard', // dashboard, subjects, daily, quiz, result, leaderboard, progress
      currentQuiz: null,
      currentQuestionIndex: 0,
      userAnswers: [],
      quizResult: null,
      quizLifelines: {},
      isDailyChallenge: false,
      currentLanguage: 'en', // 'en' | 'hi'
      soundEnabled: true,
      speechEnabled: true,
      darkMode: false,
      aiChatHistory: [],
      modals: {
        aiTutor: false,
        profile: false
      },
      isLoading: true
    };
  }

  async init() {
    try {
      // Check saved theme preference
      const savedTheme = localStorage.getItem('questify_theme');
      if (savedTheme === 'dark') {
        this.state.darkMode = true;
        document.documentElement.classList.add('dark');
        document.body.classList.add('dark');
      }

      // Load initial state from API
      const [profile, subjects, dailyChallenge, leaderboard, progress] = await Promise.all([
        API.getProfile(),
        API.getSubjects(),
        API.getDailyChallenge(),
        API.getLeaderboard('village'),
        API.getProgress()
      ]);

      this.state.userProfile = profile;
      this.state.subjects = subjects;
      this.state.dailyChallenge = dailyChallenge;
      this.state.leaderboardData = leaderboard;
      this.state.progressData = progress;
      this.state.currentLanguage = profile.preferred_language || 'en';
      this.state.isLoading = false;

      this.render();
      this.bindEvents();
    } catch (err) {
      console.error("Initialization error:", err);
      this.state.isLoading = false;
      this.render();
    }
  }

  setState(partialState) {
    this.state = { ...this.state, ...partialState };
    
    // Apply dark mode classes
    if (this.state.darkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      localStorage.setItem('questify_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      localStorage.setItem('questify_theme', 'light');
    }

    this.render();
    this.bindEvents();
  }

  triggerConfetti() {
    if (window.confetti) {
      window.confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
      setTimeout(() => {
        window.confetti({
          particleCount: 50,
          angle: 60,
          spread: 55,
          origin: { x: 0 }
        });
        window.confetti({
          particleCount: 50,
          angle: 120,
          spread: 55,
          origin: { x: 1 }
        });
      }, 250);
    }
  }

  toggleTheme() {
    SoundFX.playClick();
    this.setState({ darkMode: !this.state.darkMode });
  }

  // Quiz Execution Handlers
  async startQuiz(subjectId, mode = 'practice') {
    SoundFX.playClick();
    this.setState({ isLoading: true });

    try {
      const isDaily = mode === 'daily';
      const quiz = await API.generateQuiz(subjectId, 'medium', mode);
      
      this.setState({
        currentQuiz: quiz,
        currentQuestionIndex: 0,
        userAnswers: [],
        quizResult: null,
        quizLifelines: {},
        isDailyChallenge: isDaily,
        currentView: 'quiz',
        isLoading: false
      });

      // Auto-narrate the first question if speech is enabled
      const firstQ = quiz.questions[0];
      if (firstQ) {
        const textToRead = this.state.currentLanguage === 'hi' 
          ? `${firstQ.question_hi || firstQ.question}`
          : `${firstQ.question}`;
        SoundFX.speak(textToRead, this.state.currentLanguage);
      }
    } catch (err) {
      alert("Could not load quiz: " + err.message);
      this.setState({ isLoading: false });
    }
  }

  selectOption(optionIndex) {
    const { currentQuiz, currentQuestionIndex, userAnswers } = this.state;
    if (!currentQuiz) return;

    const currentQ = currentQuiz.questions[currentQuestionIndex];
    SoundFX.playClick();

    // Upsert answer
    const existingIndex = userAnswers.findIndex(a => a.question_id === currentQ.id);
    let updatedAnswers = [...userAnswers];

    if (existingIndex >= 0) {
      updatedAnswers[existingIndex] = {
        question_id: currentQ.id,
        selected_option_index: optionIndex,
        time_taken_seconds: 8
      };
    } else {
      updatedAnswers.push({
        question_id: currentQ.id,
        selected_option_index: optionIndex,
        time_taken_seconds: 8
      });
    }

    this.setState({ userAnswers: updatedAnswers });
  }

  use5050Lifeline() {
    const { currentQuiz, currentQuestionIndex, quizLifelines } = this.state;
    if (!currentQuiz) return;
    const currentQ = currentQuiz.questions[currentQuestionIndex];
    const lifeline = quizLifelines[currentQ.id] || {};

    if (lifeline.fiftyFiftyUsed) return;

    SoundFX.playCoin();

    // Select 2 incorrect choices to hide
    const hidden = [0, 2];
    const updated = {
      ...quizLifelines,
      [currentQ.id]: {
        ...lifeline,
        fiftyFiftyUsed: true,
        hiddenOptions: hidden
      }
    };

    this.setState({ quizLifelines: updated });
  }

  useHintLifeline() {
    const { currentQuiz, currentQuestionIndex, quizLifelines, currentLanguage } = this.state;
    if (!currentQuiz) return;
    const currentQ = currentQuiz.questions[currentQuestionIndex];
    const lifeline = quizLifelines[currentQ.id] || {};

    if (lifeline.hintUsed) return;

    SoundFX.playCoin();

    const updated = {
      ...quizLifelines,
      [currentQ.id]: {
        ...lifeline,
        hintUsed: true
      }
    };

    this.setState({ quizLifelines: updated });

    // Speak the hint out loud
    SoundFX.speak(currentQ.hint || "Think about the simplest step.", currentLanguage);
  }

  async submitCurrentQuiz() {
    const { currentQuiz, userAnswers, isDailyChallenge } = this.state;
    if (!currentQuiz) return;

    // Check if some questions unanswered
    if (userAnswers.length < currentQuiz.questions.length) {
      const confirmSubmit = confirm(
        this.state.currentLanguage === 'hi' 
          ? "कुछ प्रश्न अभी अनुत्तरित हैं। क्या आप फिर भी जमा करना चाहते हैं?" 
          : "Some questions are unanswered. Do you want to submit anyway?"
      );
      if (!confirmSubmit) return;
    }

    this.setState({ isLoading: true });
    try {
      const result = await API.submitQuiz(
        currentQuiz.quiz_id,
        currentQuiz.subject_id,
        userAnswers,
        isDailyChallenge
      );

      // Refresh profile & progress
      const [updatedProfile, updatedProgress, updatedChallenge] = await Promise.all([
        API.getProfile(),
        API.getProgress(),
        API.getDailyChallenge()
      ]);

      this.setState({
        quizResult: result,
        userProfile: updatedProfile,
        progressData: updatedProgress,
        dailyChallenge: updatedChallenge,
        currentView: 'result',
        isLoading: false
      });

      // Sound & Confetti Fanfare
      SoundFX.playFanfare();
      this.triggerConfetti();

      // Read aloud the AI feedback
      if (result.ai_analysis && result.ai_analysis.feedback_text) {
        SoundFX.speak(result.ai_analysis.feedback_text, this.state.currentLanguage);
      }
    } catch (err) {
      alert("Submission error: " + err.message);
      this.setState({ isLoading: false });
    }
  }

  async changeLeaderboardScope(scope) {
    SoundFX.playClick();
    this.setState({ isLoading: true, leaderboardScope: scope });
    try {
      const data = await API.getLeaderboard(scope);
      this.setState({ leaderboardData: data, isLoading: false });
    } catch (err) {
      console.error(err);
      this.setState({ isLoading: false });
    }
  }

  async handleAITutorSend(query) {
    if (!query || !query.trim()) return;
    SoundFX.playClick();

    const newHistory = [...this.state.aiChatHistory, { sender: 'user', text: query }];
    this.setState({ aiChatHistory: newHistory });

    try {
      const res = await API.askAITutor(query, this.state.currentLanguage, this.state.userProfile.grade);
      const updatedHistory = [...newHistory, { sender: 'ai', text: res.reply_text }];
      this.setState({ aiChatHistory: updatedHistory });

      // Speak response aloud
      SoundFX.speak(res.reply_text, this.state.currentLanguage);
    } catch (err) {
      console.error(err);
    }
  }

  render() {
    const root = document.getElementById('app');
    if (!root) return;

    if (this.state.isLoading && !this.state.userProfile) {
      root.innerHTML = `
        <div class="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white">
          <div class="w-16 h-16 rounded-2xl bg-emerald-500 text-white flex items-center justify-center font-game font-extrabold text-3xl shadow-lg animate-bounce mb-4">
            Q
          </div>
          <h2 class="font-game text-2xl font-bold">Questify</h2>
          <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Loading your learning arena...</p>
        </div>
      `;
      return;
    }

    // Determine Main View Content
    let mainViewHtml = '';
    switch (this.state.currentView) {
      case 'dashboard':
        mainViewHtml = `
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            ${renderHeroBanner(this.state)}
            ${renderDailyChallenge(this.state)}
            ${renderSubjectCards(this.state)}
          </div>
        `;
        break;
      case 'subjects':
        mainViewHtml = `
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            ${renderSubjectCards(this.state)}
          </div>
        `;
        break;
      case 'daily':
        mainViewHtml = `
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            ${renderDailyChallenge(this.state)}
          </div>
        `;
        break;
      case 'quiz':
        mainViewHtml = renderQuizScreen(this.state);
        break;
      case 'result':
        mainViewHtml = renderQuizResult(this.state);
        break;
      case 'leaderboard':
        mainViewHtml = renderLeaderboard(this.state);
        break;
      case 'progress':
        mainViewHtml = renderProgressScreen(this.state);
        break;
      default:
        mainViewHtml = `<div class="p-8 text-center">View not found</div>`;
    }

    // Full Layout Assembly
    root.innerHTML = `
      <div class="min-h-screen flex flex-col justify-between">
        
        <!-- Header -->
        ${renderHeader(this.state)}

        <!-- Main Content View Container -->
        <main class="flex-1 transition-all">
          ${mainViewHtml}
        </main>

        <!-- Footer -->
        ${renderFooter(this.state)}

        <!-- Modals -->
        ${this.state.modals.aiTutor ? renderAITutorModal(this.state) : ''}
        ${this.state.modals.profile ? renderProfileModal(this.state) : ''}

      </div>
    `;
  }

  bindEvents() {
    // Navigation items
    document.querySelectorAll('.nav-item-btn, .footer-nav-btn').forEach(btn => {
      btn.onclick = (e) => {
        const view = e.currentTarget.dataset.view;
        if (view) {
          SoundFX.playClick();
          this.setState({ currentView: view });
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      };
    });

    // Logo click -> Home
    const logoBtn = document.getElementById('nav-logo-btn');
    if (logoBtn) {
      logoBtn.onclick = () => {
        SoundFX.playClick();
        this.setState({ currentView: 'dashboard' });
      };
    }

    // Language Toggle (English <-> Hindi)
    const langBtn = document.getElementById('btn-lang-toggle');
    if (langBtn) {
      langBtn.onclick = () => {
        SoundFX.playClick();
        const nextLang = this.state.currentLanguage === 'en' ? 'hi' : 'en';
        this.setState({ currentLanguage: nextLang });
      };
    }

    // Sound Toggle
    const soundBtn = document.getElementById('btn-sound-toggle');
    if (soundBtn) {
      soundBtn.onclick = () => {
        const active = SoundFX.toggleSound();
        this.setState({ soundEnabled: active });
      };
    }

    // Dark / Light Mode Toggle Buttons
    const themeBtn = document.getElementById('btn-theme-toggle');
    const modalThemeBtn = document.getElementById('modal-btn-theme');
    [themeBtn, modalThemeBtn].forEach(btn => {
      if (btn) {
        btn.onclick = () => this.toggleTheme();
      }
    });

    // Mobile Hamburger Menu
    const mobileMenuBtn = document.getElementById('btn-mobile-menu');
    const mobileDrawer = document.getElementById('mobile-nav-drawer');
    if (mobileMenuBtn && mobileDrawer) {
      mobileMenuBtn.onclick = () => {
        mobileDrawer.classList.toggle('hidden');
      };
    }

    // Open AI Tutor Modal
    const openAIBtns = [
      document.getElementById('btn-open-ai-tutor'),
      document.getElementById('mobile-btn-open-ai-tutor')
    ];
    openAIBtns.forEach(btn => {
      if (btn) {
        btn.onclick = () => {
          SoundFX.playClick();
          this.setState({ modals: { ...this.state.modals, aiTutor: true } });
        };
      }
    });

    // Close AI Tutor Modal
    const closeAIBtn = document.getElementById('btn-close-ai-modal');
    if (closeAIBtn) {
      closeAIBtn.onclick = () => {
        SoundFX.playClick();
        SoundFX.stopSpeech();
        this.setState({ modals: { ...this.state.modals, aiTutor: false } });
      };
    }

    // Send AI Tutor Message
    const sendAIBtn = document.getElementById('btn-send-ai-chat');
    const aiInput = document.getElementById('ai-chat-input');
    if (sendAIBtn && aiInput) {
      sendAIBtn.onclick = () => {
        this.handleAITutorSend(aiInput.value);
        aiInput.value = '';
      };
      aiInput.onkeypress = (e) => {
        if (e.key === 'Enter') {
          this.handleAITutorSend(aiInput.value);
          aiInput.value = '';
        }
      };
    }

    // Quick AI Prompts
    document.querySelectorAll('.btn-quick-prompt').forEach(btn => {
      btn.onclick = (e) => {
        const p = e.currentTarget.dataset.prompt;
        if (p) this.handleAITutorSend(p);
      };
    });

    // Open Student Profile Modal
    const profileBtn = document.getElementById('btn-profile-open');
    if (profileBtn) {
      profileBtn.onclick = () => {
        SoundFX.playClick();
        this.setState({ modals: { ...this.state.modals, profile: true } });
      };
    }

    // Close Student Profile Modal
    const closeProfileBtn = document.getElementById('btn-close-profile-modal');
    const saveProfileBtn = document.getElementById('btn-save-profile');
    [closeProfileBtn, saveProfileBtn].forEach(btn => {
      if (btn) {
        btn.onclick = () => {
          SoundFX.playClick();
          this.setState({ modals: { ...this.state.modals, profile: false } });
        };
      }
    });

    // Profile Avatar Selector
    document.querySelectorAll('.btn-select-avatar').forEach(btn => {
      btn.onclick = async (e) => {
        const avId = e.currentTarget.dataset.avatarId;
        if (avId) {
          SoundFX.playClick();
          const updated = await API.updateProfile({ avatar: avId });
          this.setState({ userProfile: updated });
        }
      };
    });

    // Start Daily Challenge
    const heroDailyBtn = document.getElementById('hero-btn-daily');
    const startDailyBtn = document.getElementById('btn-start-daily-challenge');
    [heroDailyBtn, startDailyBtn].forEach(btn => {
      if (btn) {
        btn.onclick = () => this.startQuiz('gk', 'daily');
      }
    });

    // Hero Explore Subjects
    const heroSubBtn = document.getElementById('hero-btn-subjects');
    if (heroSubBtn) {
      heroSubBtn.onclick = () => {
        SoundFX.playClick();
        this.setState({ currentView: 'subjects' });
      };
    }

    // Read Hero Quote Aloud
    const heroSpeakBtn = document.getElementById('btn-hero-speak-quote');
    if (heroSpeakBtn) {
      heroSpeakBtn.onclick = () => {
        const quote = this.state.currentLanguage === 'hi'
          ? "आज गणित, विज्ञान और सामान्य ज्ञान में 150 बोनस XP सक्रिय है! तैयार हो?"
          : "Special 150 Bonus XP active today across all subjects! Ready to rise?";
        SoundFX.speak(quote, this.state.currentLanguage);
      };
    }

    // Start Subject Quiz Buttons
    document.querySelectorAll('.btn-start-subject-quiz').forEach(btn => {
      btn.onclick = (e) => {
        const subjectId = e.currentTarget.dataset.subjectId;
        if (subjectId) this.startQuiz(subjectId, 'practice');
      };
    });

    // Quiz Options Click
    document.querySelectorAll('.quiz-option').forEach(opt => {
      opt.onclick = (e) => {
        const optIdx = parseInt(e.currentTarget.dataset.optionIndex, 10);
        if (!isNaN(optIdx)) this.selectOption(optIdx);
      };
    });

    // Quiz Lifeline: 50-50
    const fiftyBtn = document.getElementById('btn-lifeline-fifty');
    if (fiftyBtn) {
      fiftyBtn.onclick = () => this.use5050Lifeline();
    }

    // Quiz Lifeline: Hint
    const hintBtn = document.getElementById('btn-lifeline-hint');
    if (hintBtn) {
      hintBtn.onclick = () => this.useHintLifeline();
    }

    // Read Question Aloud
    const speakQBtn = document.getElementById('btn-speak-question');
    if (speakQBtn) {
      speakQBtn.onclick = () => {
        const { currentQuiz, currentQuestionIndex, currentLanguage } = this.state;
        if (currentQuiz) {
          const q = currentQuiz.questions[currentQuestionIndex];
          const text = currentLanguage === 'hi' ? (q.question_hi || q.question) : q.question;
          SoundFX.speak(text, currentLanguage);
        }
      };
    }

    // Quiz Navigation: Prev, Next, Jump, Exit, Submit
    const prevBtn = document.getElementById('btn-quiz-prev');
    if (prevBtn) {
      prevBtn.onclick = () => {
        SoundFX.playClick();
        if (this.state.currentQuestionIndex > 0) {
          const nextIdx = this.state.currentQuestionIndex - 1;
          this.setState({ currentQuestionIndex: nextIdx });
          const q = this.state.currentQuiz.questions[nextIdx];
          SoundFX.speak(this.state.currentLanguage === 'hi' ? q.question_hi : q.question, this.state.currentLanguage);
        }
      };
    }

    const nextBtn = document.getElementById('btn-quiz-next');
    if (nextBtn) {
      nextBtn.onclick = () => {
        SoundFX.playClick();
        if (this.state.currentQuestionIndex < this.state.currentQuiz.total_questions - 1) {
          const nextIdx = this.state.currentQuestionIndex + 1;
          this.setState({ currentQuestionIndex: nextIdx });
          const q = this.state.currentQuiz.questions[nextIdx];
          SoundFX.speak(this.state.currentLanguage === 'hi' ? q.question_hi : q.question, this.state.currentLanguage);
        }
      };
    }

    document.querySelectorAll('.btn-quiz-jump').forEach(btn => {
      btn.onclick = (e) => {
        const targetIdx = parseInt(e.currentTarget.dataset.targetIndex, 10);
        if (!isNaN(targetIdx)) {
          SoundFX.playClick();
          this.setState({ currentQuestionIndex: targetIdx });
          const q = this.state.currentQuiz.questions[targetIdx];
          SoundFX.speak(this.state.currentLanguage === 'hi' ? q.question_hi : q.question, this.state.currentLanguage);
        }
      };
    });

    const exitBtn = document.getElementById('btn-quiz-exit');
    if (exitBtn) {
      exitBtn.onclick = () => {
        const confirmExit = confirm(
          this.state.currentLanguage === 'hi'
            ? "क्या आप सचमुच क्विज छोड़ना चाहते हैं?"
            : "Are you sure you want to exit the quiz?"
        );
        if (confirmExit) {
          SoundFX.playClick();
          SoundFX.stopSpeech();
          this.setState({ currentView: 'dashboard', currentQuiz: null });
        }
      };
    }

    const submitBtn = document.getElementById('btn-quiz-submit');
    if (submitBtn) {
      submitBtn.onclick = () => this.submitCurrentQuiz();
    }

    // Results screen actions
    const resultsDashBtn = document.getElementById('btn-results-dashboard');
    if (resultsDashBtn) {
      resultsDashBtn.onclick = () => {
        SoundFX.playClick();
        this.setState({ currentView: 'dashboard', currentQuiz: null });
      };
    }

    const resultsLeadBtn = document.getElementById('btn-results-leaderboard');
    if (resultsLeadBtn) {
      resultsLeadBtn.onclick = () => {
        SoundFX.playClick();
        this.setState({ currentView: 'leaderboard', currentQuiz: null });
      };
    }

    const startRecBtn = document.getElementById('btn-start-recommended');
    if (startRecBtn) {
      startRecBtn.onclick = (e) => {
        const subId = e.currentTarget.dataset.subjectId || 'math';
        this.startQuiz(subId, 'practice');
      };
    }

    // Speak Results Feedback
    const speakFeedbackBtn = document.getElementById('btn-results-speak-feedback');
    if (speakFeedbackBtn && this.state.quizResult) {
      speakFeedbackBtn.onclick = () => {
        SoundFX.speak(this.state.quizResult.ai_analysis.feedback_text, this.state.currentLanguage);
      };
    }

    // Leaderboard scope buttons
    document.querySelectorAll('.btn-leaderboard-scope').forEach(btn => {
      btn.onclick = (e) => {
        const scope = e.currentTarget.dataset.scope;
        if (scope) this.changeLeaderboardScope(scope);
      };
    });
  }
}

// Initialize Application on Window Load
window.addEventListener('DOMContentLoaded', () => {
  window.questifyApp = new App();
  window.questifyApp.init();
});
