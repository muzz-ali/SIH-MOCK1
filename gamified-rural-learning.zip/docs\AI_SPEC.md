# AI Specification & Pedagogical Intelligence ("Mitra AI")

## 1. Objectives
The AI layer provides 3 core capabilities:
1. **Adaptive Difficulty Engine**: Adjusts question challenge dynamically based on the student's mastery vector.
2. **Misconception Diagnosis**: Identifies root misconceptions rather than just penalizing incorrect answers.
3. **Rural-Centric Explanations**: Explains scientific and mathematical concepts using everyday rural Indian analogies (farming, local markets, village festivals, nature).

## 2. Knowledge State Modeling
- Student mastery per sub-topic is scored on a scale of `0.0` to `1.0`.
- 3 Consecutive correct answers elevate the topic mastery by `+0.15`.
- Incorrect answers flag the subtopic for personalized remediation quests.

## 3. Speech & Multilingual Synthesis
- Questions and explanations provide bilingual text structures.
- Audio synthesizer uses Web Speech API / TTS models to support low-literacy early rural learners.
