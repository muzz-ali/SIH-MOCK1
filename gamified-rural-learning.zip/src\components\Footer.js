/**
 * Responsive Footer Component for Questify
 */

export function renderFooter(state) {
  const { currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  return `
    <footer class="bg-slate-900 text-slate-300 border-t-4 border-emerald-500 pt-12 pb-8 mt-16 transition-all">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          <!-- Col 1: Brand & Mission -->
          <div class="space-y-3 md:col-span-2">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-white flex items-center justify-center font-game font-extrabold text-xl shadow-sm">
                Q
              </div>
              <span class="font-game text-2xl font-bold text-white">
                Questify
              </span>
            </div>
            <p class="text-xs sm:text-sm text-slate-400 max-w-md font-medium leading-relaxed">
              ${isHi 
                ? 'स्मार्ट और मजेदार गेम-आधारित शिक्षण मंच। गणित, विज्ञान और सामान्य ज्ञान को बनाएं रोचक, सुलभ और सशक्त!'
                : 'An engaging, gamified learning platform empowering students across Mathematics, Science, and General Knowledge with adaptive quests and instant AI feedback.'}
            </p>
            
            <div class="flex items-center gap-2 pt-2 text-xs text-emerald-400 font-semibold">
              <span>✨</span>
              <span>${isHi ? 'अनुकूली अधिगम प्रणाली सक्रिय' : 'Adaptive Learning Engine Active'}</span>
            </div>
          </div>

          <!-- Col 2: Quick Links -->
          <div class="space-y-2">
            <h4 class="font-game font-bold text-white text-sm uppercase tracking-wider mb-2">
              ${isHi ? 'त्वरित लिंक' : 'Quick Access'}
            </h4>
            <ul class="space-y-1.5 text-xs text-slate-400 font-medium">
              <li><button class="hover:text-emerald-400 transition-colors footer-nav-btn" data-view="dashboard">🏠 ${isHi ? 'डैशबोर्ड' : 'Dashboard'}</button></li>
              <li><button class="hover:text-emerald-400 transition-colors footer-nav-btn" data-view="subjects">📚 ${isHi ? 'सभी विषय' : 'Subject Quests'}</button></li>
              <li><button class="hover:text-emerald-400 transition-colors footer-nav-btn" data-view="daily">⚡ ${isHi ? 'दैनिक चुनौती' : 'Daily Sprint'}</button></li>
              <li><button class="hover:text-emerald-400 transition-colors footer-nav-btn" data-view="leaderboard">🏆 ${isHi ? 'लीडरबोर्ड' : 'Leaderboards'}</button></li>
              <li><button class="hover:text-emerald-400 transition-colors footer-nav-btn" data-view="progress">📊 ${isHi ? 'प्रगति एवं बैज' : 'My Progress'}</button></li>
            </ul>
          </div>

          <!-- Col 3: Core Learning Tracks -->
          <div class="space-y-2">
            <h4 class="font-game font-bold text-white text-sm uppercase tracking-wider mb-2">
              ${isHi ? 'मुख्य विषय' : 'Core Tracks'}
            </h4>
            <ul class="space-y-1.5 text-xs text-slate-400">
              <li>🔢 Mathematics (गणित)</li>
              <li>🌱 Science (विज्ञान)</li>
              <li>🌾 General Knowledge (सामान्य ज्ञान)</li>
            </ul>
          </div>

        </div>

        <!-- Bottom Copyright & Motto Bar -->
        <div class="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <p>© 2026 Questify Platform • All Rights Reserved</p>
          <p class="font-medium text-emerald-400/90">
            ${isHi ? '"सीखना कोई बोझ नहीं, यह तो प्रगति का उत्सव है!" 🌟' : '"Learning should not feel like a burden. It should feel like progress." 🌟'}
          </p>
        </div>

      </div>
    </footer>
  `;
}
