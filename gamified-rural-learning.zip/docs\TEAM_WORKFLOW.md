# SIH Team Roles & Workflow Protocol

| Member | Role | Key Deliverables |
|---|---|---|
| **Farhan** | Frontend Engineer | SPA UI/UX, Gamified Quests, Quiz Arena, Mitra AI Chat UI, Audio TTS, Offline Mode |
| **Rehan & Nabeel** | Backend Engineers | Python FastAPI, PostgreSQL schemas, 200 Question DB, Grading logic, Leaderboard rankings |
| **Person 3** | AI Engineer | Adaptive difficulty model, personalized recommendation algorithms, misconception prompts |
| **Muzammil** | Tech Lead & Integration | API contract enforcement, GitHub repository merge, end-to-end integration testing, presentation demo |
| **Presentation Team** | Slides & Script | 10-Slide Pitch deck covering Rural problem, Gamified solution, Architecture, Live Demo & Impact |

## Collaboration Rules
1. All API interactions must strictly abide by `docs/API.md`.
2. Frontend maintains a mock layer allowing autonomous UI development before backend deployment.
3. No secrets or credentials committed to repository.
