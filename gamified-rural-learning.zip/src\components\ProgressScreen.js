/**
 * Progress & Mastery Screen Component for Questify
 */

export function renderProgressScreen(state) {
  const { progressData, userProfile, currentLanguage } = state;
  const isHi = currentLanguage === 'hi';

  if (!progressData) return '';

  const { overall_mastery, quizzes_completed, total_questions_solved, average_accuracy, streak_history, subject_mastery } = progressData;

  const allBadges = [
    { id: "b1", name: "Math Wizard", name_hi: "गणित का जादूगर", icon: "🔢", desc: "Score 100% on Math Quizzes", unlocked: true },
    { id: "b2", name: "5-Day Streak", name_hi: "5 दिन की लपट", icon: "🔥", desc: "Study 5 days in a row", unlocked: true },
    { id: "b3", name: "Science Explorer", name_hi: "विज्ञान खोजी", icon: "🌱", desc: "Complete 10 Science Quests", unlocked: true },
    { id: "b4", name: "Speed Master", name_hi: "तेज दिमाग", icon: "⚡", desc: "Answer 5 questions under 30s", unlocked: true },
    { id: "b5", name: "GK Champion", name_hi: "सामान्य ज्ञान सितारा", icon: "🌾", desc: "Master General Knowledge", unlocked: true },
    { id: "b6", name: "School Champion", name_hi: "स्कूल टॉपर", icon: "👑", desc: "Reach Top 3 in School", unlocked: false },
    { id: "b7", name: "Quest Titan", name_hi: "क्वेस्ट महारथी", icon: "🛡️", desc: "Solve 500 questions", unlocked: false },
    { id: "b8", name: "Grand Master", name_hi: "ग्रैंड मास्टर", icon: "✨", desc: "Complete 20 daily sprints", unlocked: false }
  ];

  return `
    <div class="max-w-4xl mx-auto py-4 px-2 sm:px-4 space-y-6">
      
      <!-- Screen Header -->
      <div class="flex items-center justify-between flex-wrap gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-3xl">📊</span>
            <h2 class="text-2xl sm:text-3xl font-game font-bold text-slate-900 dark:text-white">
              ${isHi ? 'आपकी सीखने की प्रगति' : 'Learning Progress & Achievements'}
            </h2>
          </div>
          <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">
            ${isHi ? 'हर दिन अभ्यास करें, नए बैज जीतें और अपनी क्षमता बढ़ाएं' : 'Track your consistency, subject mastery, and unlocked trophies'}
          </p>
        </div>

        <div class="px-4 py-2 rounded-2xl bg-emerald-50 dark:bg-emerald-950 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300 font-game font-bold text-sm">
          ⚡ ${userProfile.xp} Total XP
        </div>
      </div>

      <!-- Quick Metrics Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="card-rural p-4 text-center bg-white dark:bg-slate-800">
          <span class="text-2xl">🎯</span>
          <p class="font-game font-bold text-2xl text-slate-800 dark:text-slate-100 mt-1">${overall_mastery}%</p>
          <p class="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">${isHi ? 'कुल महारत' : 'Mastery'}</p>
        </div>
        <div class="card-rural p-4 text-center bg-white dark:bg-slate-800">
          <span class="text-2xl">📝</span>
          <p class="font-game font-bold text-2xl text-slate-800 dark:text-slate-100 mt-1">${quizzes_completed}</p>
          <p class="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">${isHi ? 'क्विज पूरे किए' : 'Quizzes Done'}</p>
        </div>
        <div class="card-rural p-4 text-center bg-white dark:bg-slate-800">
          <span class="text-2xl">💡</span>
          <p class="font-game font-bold text-2xl text-slate-800 dark:text-slate-100 mt-1">${total_questions_solved}</p>
          <p class="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">${isHi ? 'प्रश्न हल किए' : 'Questions Solved'}</p>
        </div>
        <div class="card-rural p-4 text-center bg-white dark:bg-slate-800">
          <span class="text-2xl">✨</span>
          <p class="font-game font-bold text-2xl text-slate-800 dark:text-slate-100 mt-1">${average_accuracy}%</p>
          <p class="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">${isHi ? 'सटीकता' : 'Accuracy'}</p>
        </div>
      </div>

      <!-- 7-Day Habit Streak Calendar -->
      <div class="card-rural p-6 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-2">
            <span class="text-2xl animate-flame">🔥</span>
            <h3 class="font-game text-lg font-bold text-slate-900 dark:text-white">
              ${isHi ? '7-दिवसीय लपट कैलेंडर (7-Day Streak)' : '7-Day Learning Habit Track'}
            </h3>
          </div>
          <span class="px-2.5 py-1 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 text-xs font-bold font-game">
            ${userProfile.streak_days} ${isHi ? 'दिन लगातार!' : 'Days Active!'}
          </span>
        </div>

        <div class="grid grid-cols-7 gap-2 sm:gap-3 text-center">
          ${streak_history.map(day => `
            <div class="p-3 rounded-2xl border-2 ${day.completed ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-300 dark:border-amber-700' : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700'} flex flex-col items-center justify-center gap-1.5 transition-all">
              <span class="text-xs font-bold text-slate-600 dark:text-slate-400">${day.day}</span>
              <div class="w-9 h-9 rounded-xl ${day.completed ? 'bg-amber-400 text-amber-950 shadow-sm' : 'bg-slate-200 dark:bg-slate-700 text-slate-400'} flex items-center justify-center text-base font-bold">
                ${day.completed ? '🔥' : '○'}
              </div>
              <span class="text-[10px] font-medium text-slate-400">${day.date}</span>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Subject Mastery Progress Breakdown (3 Core Subjects) -->
      <div class="card-rural p-6 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm">
        <h3 class="font-game text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📚</span>
          <span>${isHi ? 'विषयवार महारत प्रतिशत' : 'Subject Mastery Breakdown'}</span>
        </h3>

        <div class="space-y-4">
          ${subject_mastery.map(sub => `
            <div class="space-y-1.5">
              <div class="flex justify-between text-xs font-bold">
                <span class="text-slate-800 dark:text-slate-200">${isHi ? (sub.name_hi || sub.name) : sub.name}</span>
                <span class="text-emerald-700 dark:text-emerald-400">${sub.percentage}%</span>
              </div>
              <div class="w-full h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5 border border-slate-200 dark:border-slate-600">
                <div class="h-full rounded-full ${sub.color} transition-all duration-500" style="width: ${sub.percentage}%;"></div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Badge Showcase Gallery -->
      <div class="card-rural p-6 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <h3 class="font-game text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>🎖️</span>
            <span>${isHi ? 'आपके अर्जित बैज एवं ट्रॉफियां' : 'Badge Showcase Gallery'}</span>
          </h3>
          <span class="text-xs font-bold text-slate-500 dark:text-slate-400">5 / 8 ${isHi ? 'खुले हुए' : 'Unlocked'}</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
          ${allBadges.map(b => `
            <div class="p-4 rounded-2xl border-2 ${b.unlocked ? 'bg-gradient-to-b from-amber-50 to-white dark:from-amber-950/30 dark:to-slate-800 border-amber-300 dark:border-amber-700 shadow-sm' : 'bg-slate-50 dark:bg-slate-900 border-dashed border-slate-300 dark:border-slate-700 opacity-50'} text-center flex flex-col items-center justify-between gap-2 transition-all">
              <div class="w-14 h-14 rounded-2xl ${b.unlocked ? 'bg-amber-100 dark:bg-amber-900/50 border border-amber-300 dark:border-amber-700' : 'bg-slate-200 dark:bg-slate-700'} flex items-center justify-center text-3xl shadow-sm">
                ${b.unlocked ? b.icon : '🔒'}
              </div>
              <div>
                <h4 class="font-game font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100">${isHi ? (b.name_hi || b.name) : b.name}</h4>
                <p class="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 leading-tight">${b.desc}</p>
              </div>
              <span class="px-2 py-0.5 rounded-md text-[9px] font-bold uppercase ${b.unlocked ? 'bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}">
                ${b.unlocked ? 'Unlocked' : 'Locked'}
              </span>
            </div>
          `).join('')}
        </div>
      </div>

    </div>
  `;
}
