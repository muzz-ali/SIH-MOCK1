/**
 * Quiz Results & AI Diagnostic Screen Component for Questify
 */

export function renderQuizResult(state) {
  const { quizResult, currentLanguage, userProfile } = state;
  const isHi = currentLanguage === 'hi';

  if (!quizResult) return '';

  const {
    score,
    total_questions,
    accuracy_percentage,
    xp_earned,
    bonus_xp,
    new_total_xp,
    leveled_up,
    new_level,
    ai_analysis,
    question_breakdown
  } = quizResult;

  const isPerfect = accuracy_percentage === 100;
  const isPassed = accuracy_percentage >= 60;

  return `
    <div class="max-w-4xl mx-auto py-4 px-2 sm:px-4 space-y-6">
      
      <!-- Top Victory Card with Fanfare & Stars -->
      <div class="card-rural p-6 sm:p-8 bg-gradient-to-br from-emerald-600 via-teal-700 to-sky-800 text-white border-emerald-500/40 relative overflow-hidden text-center shadow-xl">
        
        <div class="relative z-10 max-w-xl mx-auto space-y-4">
          
          <!-- Big Badge Icon -->
          <div class="w-20 h-20 mx-auto rounded-3xl bg-amber-400 text-slate-900 flex items-center justify-center text-4xl shadow-lg transform hover:scale-110 transition-transform">
            ${isPerfect ? '👑' : (isPassed ? '🌟' : '✨')}
          </div>

          <div>
            <span class="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider mb-2">
              <span>🎉</span> ${isHi ? 'क्विज परिणाम' : 'Quiz Complete'}
            </span>
            <h2 class="text-3xl sm:text-4xl font-extrabold font-game text-white drop-shadow-sm">
              ${isPerfect 
                ? (isHi ? 'शानदार! शत-प्रतिशत सही!' : 'Flawless Victory!') 
                : (isPassed ? (isHi ? 'बहुत बढ़िया! अच्छा प्रयास!' : 'Great Work!') : (isHi ? 'अच्छा प्रयास! सीखते रहो!' : 'Good Effort! Keep Growing!'))}
            </h2>
            <p class="text-sm sm:text-base text-emerald-100 font-medium mt-1">
              ${isHi ? `आपने ${total_questions} में से ${score} प्रश्न सही हल किए (${accuracy_percentage}%)` : `You scored ${score} out of ${total_questions} correct (${accuracy_percentage}% Accuracy)`}
            </p>
          </div>

          <!-- XP Earned & Level Stats Pill -->
          <div class="flex items-center justify-center gap-4 flex-wrap pt-2">
            <div class="px-5 py-2.5 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center gap-2">
              <span class="text-2xl animate-mascot">⚡</span>
              <div class="text-left">
                <p class="text-[10px] uppercase font-bold text-emerald-200">${isHi ? 'XP अर्जित किए' : 'XP Gained'}</p>
                <p class="text-xl font-game font-bold text-amber-300">+${xp_earned} XP</p>
              </div>
            </div>

            <div class="px-5 py-2.5 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center gap-2">
              <span class="text-2xl">🔥</span>
              <div class="text-left">
                <p class="text-[10px] uppercase font-bold text-emerald-200">${isHi ? 'लपट (Streak)' : 'Streak'}</p>
                <p class="text-xl font-game font-bold text-white">${userProfile.streak_days} ${isHi ? 'दिन' : 'Days'}</p>
              </div>
            </div>

            ${leveled_up ? `
              <div class="px-5 py-2.5 rounded-2xl bg-amber-400 text-amber-950 font-bold flex items-center gap-2 shadow-lg animate-bounce">
                <span class="text-2xl">🏆</span>
                <div class="text-left">
                  <p class="text-[10px] uppercase font-extrabold text-amber-900">${isHi ? 'लेवल अप!' : 'LEVEL UP!'}</p>
                  <p class="text-xl font-game font-bold">Level ${new_level}</p>
                </div>
              </div>
            ` : ''}
          </div>

        </div>

      </div>

      <!-- AI Diagnostic Report & Personalized Remediation -->
      <div class="card-rural p-6 sm:p-7 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-md">
        
        <div class="flex items-center gap-3 mb-4">
          <div class="w-12 h-12 rounded-2xl bg-violet-100 dark:bg-violet-950 border-2 border-violet-300 dark:border-violet-700 text-violet-700 dark:text-violet-300 flex items-center justify-center text-2xl">
            🤖
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="font-game text-xl font-bold text-slate-900 dark:text-white">
                ${isHi ? 'क्वेस्ट AI प्रदर्शन विश्लेषण' : 'Quest AI Performance Diagnosis'}
              </h3>
              <span class="px-2 py-0.5 rounded-md text-[10px] font-bold bg-violet-100 dark:bg-violet-950 text-violet-800 dark:text-violet-300 border border-violet-200 dark:border-violet-700">
                Adaptive AI
              </span>
            </div>
            <p class="text-xs text-slate-500 dark:text-slate-400 font-medium">
              ${isHi ? 'आपके ज्ञान और समझ का व्यक्तिगत विश्लेषण' : 'Personalized insights generated for your learning pace'}
            </p>
          </div>
        </div>

        <!-- Strong & Weak Topics Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
          
          <div class="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
            <p class="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase flex items-center gap-1.5 mb-2">
              <span>🌟</span> ${isHi ? 'मजबूत विषय (Your Strengths)' : 'Strong Topics'}
            </p>
            <div class="flex flex-wrap gap-2">
              ${ai_analysis.strong_topics.map(t => `
                <span class="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300 text-xs font-bold shadow-sm">
                  ✔ ${t}
                </span>
              `).join('')}
            </div>
          </div>

          <div class="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
            <p class="text-xs font-bold text-amber-800 dark:text-amber-300 uppercase flex items-center gap-1.5 mb-2">
              <span>🎯</span> ${isHi ? 'अभ्यास के लिए विषय (Practice Focus)' : 'Topics to Practice'}
            </p>
            <div class="flex flex-wrap gap-2">
              ${ai_analysis.weak_topics.map(t => `
                <span class="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300 text-xs font-bold shadow-sm">
                  ⚡ ${t}
                </span>
              `).join('')}
            </div>
          </div>

        </div>

        <!-- Quest AI Personalized Advice Speech Bubble -->
        <div class="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 relative mb-5">
          <p class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">${isHi ? 'क्वेस्ट AI की सलाह' : 'Quest AI Feedback'}</p>
          <p class="text-sm sm:text-base font-semibold text-slate-800 dark:text-slate-100 leading-relaxed">
            "${ai_analysis.feedback_text}"
          </p>
          <button id="btn-results-speak-feedback" class="mt-2 text-xs font-bold text-violet-600 dark:text-violet-400 hover:underline flex items-center gap-1">
            <span>🔊</span> <span>${isHi ? 'सलाह सुनें' : 'Listen to Advice'}</span>
          </button>
        </div>

        <!-- Next Recommended Action -->
        ${ai_analysis.recommended_quiz ? `
          <div class="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-violet-500/10 to-indigo-50 dark:from-violet-950/40 dark:to-slate-900 border border-violet-200 dark:border-violet-800 flex-wrap gap-3">
            <div>
              <p class="text-xs font-bold text-violet-900 dark:text-violet-300 uppercase">${isHi ? 'अनुशंसित अगला अभ्यास' : 'Recommended Next Quest'}</p>
              <h4 class="font-game text-base font-bold text-slate-800 dark:text-slate-100">${ai_analysis.recommended_quiz.title}</h4>
            </div>
            <button class="btn-3d btn-3d-purple px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm" id="btn-start-recommended" data-subject-id="${ai_analysis.recommended_quiz.subject_id}">
              <span>🚀</span>
              <span>${isHi ? 'अभ्यास शुरू करें (+100 XP)' : 'Start Practice (+100 XP)'}</span>
            </button>
          </div>
        ` : ''}

      </div>

      <!-- Step-by-Step Question Review & Explanations -->
      <div class="card-rural p-6 sm:p-7 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-md">
        
        <div class="flex items-center justify-between mb-4">
          <h3 class="font-game text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>📖</span>
            <span>${isHi ? 'प्रश्नों का विस्तार से विश्लेषण' : 'Detailed Question Review'}</span>
          </h3>
          <span class="text-xs font-bold text-slate-500 dark:text-slate-400">${question_breakdown.length} ${isHi ? 'प्रश्न' : 'Questions'}</span>
        </div>

        <div class="space-y-4">
          ${question_breakdown.map((item, idx) => {
            const isCorrect = item.is_correct;
            const qTitle = isHi ? (item.question_text_hi || item.question_text) : item.question_text;
            const correctAns = isHi ? (item.correct_option_text_hi || item.correct_option_text) : item.correct_option_text;

            return `
              <div class="p-4 sm:p-5 rounded-2xl border-2 ${isCorrect ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800' : 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800'} space-y-2.5">
                
                <div class="flex items-start justify-between gap-2">
                  <div class="flex items-start gap-2.5">
                    <span class="w-6 h-6 shrink-0 rounded-full ${isCorrect ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'} flex items-center justify-center text-xs font-bold font-game">
                      ${idx + 1}
                    </span>
                    <h4 class="font-semibold text-sm sm:text-base text-slate-900 dark:text-slate-100 leading-snug">
                      ${qTitle}
                    </h4>
                  </div>
                  <span class="px-2.5 py-1 rounded-full text-xs font-bold shrink-0 ${isCorrect ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300' : 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300'}">
                    ${isCorrect ? (isHi ? '✔ सही' : '✔ Correct') : (isHi ? '✖ गलत' : '✖ Incorrect')}
                  </span>
                </div>

                <div class="text-xs font-semibold text-slate-600 dark:text-slate-300 pl-8 space-y-1">
                  <p><span class="text-slate-400">${isHi ? 'सही उत्तर:' : 'Correct Answer:'}</span> <strong class="text-emerald-700 dark:text-emerald-400">${correctAns}</strong></p>
                  <p class="text-slate-700 dark:text-slate-200 bg-white/80 dark:bg-slate-900/80 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 mt-1.5 leading-relaxed">
                    💡 <strong class="text-slate-900 dark:text-white">${isHi ? 'व्याख्या:' : 'Explanation:'}</strong> ${item.explanation}
                  </p>
                </div>

              </div>
            `;
          }).join('')}
        </div>

      </div>

      <!-- Bottom Action Buttons -->
      <div class="flex items-center justify-center gap-4 flex-wrap pt-2">
        <button id="btn-results-dashboard" class="btn-3d btn-3d-primary px-7 py-3.5 rounded-2xl text-base font-bold flex items-center gap-2 shadow-lg">
          <span>🏠</span>
          <span>${isHi ? 'डैशबोर्ड पर वापस जाएं' : 'Back to Dashboard'}</span>
        </button>
        <button id="btn-results-leaderboard" class="btn-3d btn-3d-amber px-6 py-3.5 rounded-2xl text-base font-bold flex items-center gap-2 shadow-lg">
          <span>🏆</span>
          <span>${isHi ? 'लीडरबोर्ड देखें' : 'View Leaderboard'}</span>
        </button>
      </div>

    </div>
  `;
}
